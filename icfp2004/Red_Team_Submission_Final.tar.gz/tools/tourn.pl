#!/usr/bin/perl
#
#   A new version of tournament.pl that tracks kills too.
#
#   Args: all the bots to play off
#
use strict ;
$|++ ;
my $offset ;
my $first ;
my $second ;
my @competitors = (@ARGV) ;
my $n = @ARGV ;
my @wins = (0) x $n ;
my @losses = (0) x $n ;
my @ties = (0) x $n ;
my @games = (0) x $n ;
my @scoresum = (0) x $n ;
my @deathsum = (0) x $n ;
my @killsum = (0) x $n ;
my @sum ;
my %result ;
my %detail ;
my $matchups = 0 ;
sub sumit {
   open TSUM, ">md5.tmp" or die "Can't open md5.tmp" ;
   print TSUM join " <><> ", @_ ;
   close TSUM ;
   my $sum = `md5sum md5.tmp` ;
   $sum = (split " ", $sum)[0] ;
   return $sum ;
}
sub against {
   my ($first, $second) = @_ ;
   my $key = "$first-$second" ;
   return if $result{$key} ;
   my $k1 = $sum[$first] ;
   my $k2 = $sum[$second] ;
   my $cachekey = "" ;
   if ($k1 lt $k2) {
      $cachekey = sumit($k1, $k2) ;
   } else {
      $cachekey = sumit($k2, $k1) ;
   }
   my $w1 = 0 ;
   my $w2 = 0 ;
   my $l1 = 0 ;
   my $l2 = 0 ;
   my $t = 0 ;
   my $g = 0 ;
   my $ss1 = 0 ;
   my $ss2 = 0 ;
   my $ds1 = 0 ;
   my $ds2 = 0 ;
   my $ks1 = 0 ;
   my $ks2 = 0 ;
   if (-f "tcache2/$cachekey.res") {
      my $tk1 ;
      my $tk2 ;
      ($tk1, $tk2, $w1, $l1, $t, $g, $ss1, $ss2, $ds1, $ds2, $ks1, $ks2) =
         split " ", `cat tcache2/$cachekey.res` ;
      die "Bad cache entry tcache2/$cachekey.res" if !defined $ds2 ;
      $w2 = $l1 ;
      $l2 = $w1 ;
      if ($k1 ge $k2) {
         ($tk1, $tk2, $w1, $w2, $l1, $l2, $ss1, $ss2, $ds1, $ds2, $ks1, $ks2) =
         ($tk2, $tk1, $w2, $w1, $l2, $l1, $ss2, $ss1, $ds2, $ds1, $ks2, $ks1) ;
      }
      die "Key mismatch: $k1 $tk1" if ($k1 ne $tk1) ;
      die "Key mismatch: $k1 $tk1" if ($k2 ne $tk2) ;
      $games[$first] += $g ;
      $games[$second] += $g ;
      $scoresum[$first] += $ss1 ;
      $scoresum[$second] += $ss2 ;
      $deathsum[$first] += $ds1 ;
      $deathsum[$second] += $ds2 ;
      $killsum[$first] += $ks1 ;
      $killsum[$second] += $ks2 ;
      $wins[$first] += $w1 ;
      $wins[$second] += $w2 ;
      $losses[$first] += $l1 ;
      $losses[$second] += $l2 ;
      $ties[$first] += $t ;
      $ties[$second] += $t ;
   } else {
      print "./sim all $competitors[$first] $competitors[$second] 0\n" ;
      open F, "./sim all $competitors[$first] $competitors[$second] 0|"
                                or die "Can't start sim $first $second $!\n" ;
      while (<F>) {
         if (/^%s (\d+) (\d+)/) {
            my $s1 = $1 ;
            my $s2 = $2 ;
            $g++ ;
            $games[$first]++ ;
            $games[$second]++ ;
            $scoresum[$first] += $s1 ;
            $scoresum[$second] += $s2 ;
            $ss1 += $s1 ;
            $ss2 += $s2 ;
            if ($s1 > $s2) {
               $wins[$first]++ ;
               $losses[$second]++ ;
               $w1++ ;
               $l2++ ;
               print "W" ;
            } elsif ($s1 == $s2) {
               $ties[$first]++ ;
               $ties[$second]++ ;
               $t++ ;
               print "T" ;
            } else {
               $wins[$second]++ ;
               $losses[$first]++ ;
               $w2++ ;
               $l1++ ;
               print "L" ;
            }
         } elsif (/^%d (\d+) (\d+)/) {
            $deathsum[$first] += $1 ;
            $deathsum[$second] += $2 ;
            $killsum[$first] += $2 ;
            $killsum[$second] += $1 ;
            $ds1 += $1 ;
            $ds2 += $2 ;
            $ks1 += $2 ;
            $ks2 += $1 ;
         }
      }
      close F ;
      print "\n" ;
      open F, ">tcache2/$cachekey.res" or die "Can't open tcache2/$cachekey.res" ;
      if ($k1 lt $k2) {
         print F "$k1 $k2 $w1 $l1 $t $g $ss1 $ss2 $ds1 $ds2 $ks1 $ks2\n" ;
      } else {
         print F "$k2 $k1 $w2 $l2 $t $g $ss2 $ss1 $ds2 $ds1 $ks2 $ks1\n" ;
      }
      close F ;
      $matchups++ ;
      print "$competitors[$first] ($w1-$l1-$t) $competitors[$second] ($w2-$l2-$t)\n" ;
   }
   $result{"$first-$second"} = "$w1-$l1-$t" ;
   $result{"$second-$first"} = "$w2-$l2-$t" ;
   $ks1 = int($ks1/$g+$g/2) ;
   $ds1 = int($ds1/$g+$g/2) ;
   $ks2 = int($ks2/$g+$g/2) ;
   $ds2 = int($ds2/$g+$g/2) ;
   $detail{"$first-$second"} = "${ks1}K ${ds1}D" ;
   $detail{"$second-$first"} = "${ks2}K ${ds2}D" ;
}
my $i ;
mkdir "tcache2" if ! -d "tcache2" ;
for ($i=0; $i<$n; $i++) {
   $_ = $competitors[$i] ;
   die "Nonexistent $_" if ! -f $_ ;
   my $sum = `md5sum $_` ;
   $sum = (split " ", $sum)[0] ;
   $sum[$i] = $sum ;
   if (! -f "tcache2/$sum.src") {
      open F, ">tcache2/$sum.src" or die "Can't open tcache2/sum.src" ;
      print F `cat $_` ;
      close F ;
   }
}
my $lastmatchups = 0 ;
sub show_standings() {
   return if $matchups == $lastmatchups ;
   $lastmatchups = $matchups ;
   my @const = sort { ((2*$wins[$b]+$ties[$b]) <=>
                       (2*$wins[$a]+$ties[$a])) ||
                      ($scoresum[$b] <=> $scoresum[$a]) } 0..$n-1 ;
   print "Place            Name                           Record        Av Score  Av Kills  Av Deaths\n" ;
   for ($i=0; $i<@const; $i++) {
      $_ = $const[$i] ;
      printf("%2d %40s (%3d-%3d-%2d) %10s %10s %10s\n", 1+$i, $competitors[$_], $wins[$_],
             $losses[$_], $ties[$_], int(10*$scoresum[$_]/$games[$_])/10,
             int(10*$killsum[$_]/$games[$_])/10,
             int(10*$deathsum[$_]/$games[$_])/10) ;
   }
   my $j ;
   print "\n" ;
   for ($j=0; $j<@const; $j++) {
      printf("%8d", 1+$j) ;
   }
   printf("\n") ;
   for ($i=0; $i<@const; $i++) {
      printf("%2d", 1+$i) ;
      for ($j=0; $j<@const; $j++) {
         printf("%8s", $result{$const[$i].'-'.$const[$j]}) ;
      }
      printf("\n") ;
      print ("  ") ;
      for ($j=0; $j<@const; $j++) {
         printf("%8s", $detail{$const[$i].'-'.$const[$j]}) ;
      }
      printf("\n") ;
   }
}
for ($offset=1; $offset<$n; $offset++) {
   for ($first=0; $first<$n; $first++) {
      $second = ($first + $offset) % $n ;
      against($first, $second) ;
   }
   show_standings() ;
}
$matchups++ if ($matchups == 0) ;
show_standings() ;
