/**********************************************************************
 * 
 * The ants will be identified as antXY according to this layout:
 *   
 *             00  10  20  30  40  50
 *           01  11  21  31  41  51  61
 *         02  12  22  32  42  52  62  72
 *       03  13  23  33  43  53  63  73  83
 *     04  14  24  34  44  54  64  74  84  94
 *   05  15  25  35  45  55  65  75  85  95  A5
 *     06  16  26  36  46  56  66  76  86  96
 *       07  17  27  37  47  57  67  77  87
 *         08  18  28  38  48  58  68  78
 *           09  19  29  39  49  59  69
 *             0A  1A  2A  3A  4A  5A
 * 
 * First the X coordinate is identified, first X=0, then X=1, etc.
 * This is done in the "antXY" section.
 * 
 * Then inside each X coordinate the Y coordinate is identified,
 * starting with Y=max(0,X-5). Not that X=A doesn't need further
 * identification, since the only possible Y value for it is 5.
 * This is done in the "ant0..9Y" section.
 * 
 * Then the behaviour for each antXY is defined. Each ant does the
 * same:
 * 
 *   - mark
 *   - wait
 *   - unmark
 *   - turn right
 *   - turn right
 *   - turn right
 *   - wait for everybody
 * 
 * Not every ant needs to to everything of this, though.
 * 
 *   - Marking needs to be done by all but the bottommost two of
 *     each "X-column" in order to identify the remaining Y coordinates
 *     below.
 *   - Waiting is for those that mark and where the next ant needs
 *     to turn first in order to sense. I.e. those with Y=5 need to
 *     wait a moment before unmarking.
 *   - Unmark: Those who marked.
 *   - Turn right: Everybody
 *   - Turn right: Everybody with Y>=6 because they turned left for sensing
 *     the ant above.
 *   - Turn right: Only A5.
 *   - Wait for everybody: Everybody whose done faster than the slowest ;-)
 *     This is a little complicated. Let's not count the first three
 *     "turn left". Then X=0 is *identified* in round #0 (I start counting
 *     with 0) and label "ant0Y" is reached in round #1. All ant0X then
 *     do (mark,unmark,right,right)... puh, I'd much rather let this
 *     simulate and just look how long each one must wait... ;-)
 *     
 **********************************************************************/

#include <iostream>
using namespace std;

char hex ( int i ) {
  return char( (i < 10) ? i+'0' : i-10+'A' );
}

int main () {
  
  //--- The repeat macros.
  
  cout << "define(`repeat0', )" << endl;
  for( int r=1; r<31; r++ ){
    cout << "define(`repeat" << r << "', $1";
    for( int i=1; i<r; i++ )
      cout << "\n$1";
    cout << ")" << endl;
  }
  cout << endl;
  
  //--- antXY:
  
  cout << "antXY:" << endl;
  cout << "repeat3(turn left)" << endl;
  cout << "if ! sense ahead friend {\n  goto ant0Y\n}" << endl;
  for( int x=1; x<10; x++ )
    cout << "if sense ahead marker 0 {\n  goto ant" << x << "Y\n}" << endl;
  cout << "goto antA5" << endl;
  cout << endl;
  
  //--- ant0..9Y:
  
  for( int x=0; x<10; x++ ){
    int offset = max( 0, x-5 );
    cout << "ant" << x << "Y:" << endl;
    if( x < 9 ){
      cout << "mark 0" << endl;
      cout << "unmark 0" << endl;
    }
    cout << "repeat2(turn right)" << endl;
    cout << "if ! sense ahead friend {\n goto ant" << x << offset << "\n}" << endl;
    for( int y=offset+1; y<10-offset ; y++ ){
      if( y == 6  &&  x < 9 )
	cout << "turn left" << endl;
      cout << "if sense ahead marker 0 {\n  goto ant" << x << y << "\n}" << endl;
    }
    cout << "goto ant" << x << hex(10-offset) << endl;
    cout << endl;
  }
  
  //--- Single ant instructions:
  
  for( int x=0; x<=10; x++ ){
    int offset = max( 0, x-5 );
    for( int y=offset; y<=10-offset; y++ ){
      
      cout << "ant" << hex(x) << hex(y) << ":" << endl;
      if( y < 9-offset ){
	cout << "mark 0" << endl;
	if( y == 5 )
	  cout << "mark 0" << endl;
	cout << "unmark 0" << endl;
      }
      cout << "turn right" << endl;
      if( y >= 6 )
	cout << "turn right" << endl;
      if( x == 10 )
	cout << "turn right" << endl;
      int waitRounds = 0;
      cout << "repeat" << waitRounds << "(unmark 0)" << endl;
      cout << "goto start_ant" << hex(x) << hex(y) << endl;
      cout << endl;
    }
  }

  for( int x=0; x<=10; x++ ){
    int offset = max( 0, x-5 );
    for( int y=offset; y<=10-offset; y++ ){
      cout << "start_ant" << hex(x) << hex(y) << ":" << endl;
      cout << "unmark 2" << endl;
      if( (x+y)&1 )
	cout << "goto act_like_a_left_turner" << endl;
      else
	cout << "goto act_like_a_marker" << endl;
    }
  }
  cout << endl;
  
  cout << "act_like_a_marker:" << endl;
  cout << "mark 5" << endl;
  cout << "goto act_like_a_marker" << endl;
  cout << endl;
  
  cout << "act_like_a_left_turner:" << endl;
  cout << "turn left" << endl;
  cout << "goto act_like_a_left_turner" << endl;
  cout << endl;
  
  cout << "act_like_a_right_turner:" << endl;
  cout << "turn right" << endl;
  cout << "goto act_like_a_right_turner" << endl;
  cout << endl;
  
  cout << "act_like_a_walker:" << endl;
  cout << "move" << endl;
  cout << "goto act_like_a_walker" << endl;
  cout << endl;
}
