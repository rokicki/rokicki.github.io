#!/usr/bin/perl
#
#   Args: all the bots to play off
#
use strict ;
$|++ ;
my $offset ;
my $first ;
my $second ;
my @competitors = (@ARGV) ;
my $n = @ARGV ;
my @wins = (0) x $n ;
my @losses = (0) x $n ;
my @ties = (0) x $n ;
my @games = (0) x $n ;
my @scoresum = (0) x $n ;
my @deathsum = (0) x $n ;
my @sum ;
my %result ;
my $matchups = 0 ;
sub sumit {
   open TSUM, ">md5.tmp" or die "Can't open md5.tmp" ;
   print TSUM join " <><> ", @_ ;
   close TSUM ;
   my $sum = `md5sum md5.tmp` ;
   $sum = (split " ", $sum)[0] ;
   return $sum ;
}
sub against {
   my ($first, $second) = @_ ;
   my $key = "$first-$second" ;
   return if $result{$key} ;
   my $k1 = $sum[$first] ;
   my $k2 = $sum[$second] ;
   my $cachekey = "" ;
   if ($k1 lt $k2) {
      $cachekey = sumit($k1, $k2) ;
   } else {
      $cachekey = sumit($k2, $k1) ;
   }
   my $w1 = 0 ;
   my $w2 = 0 ;
   my $l1 = 0 ;
   my $l2 = 0 ;
   my $t = 0 ;
   my $g = 0 ;
   my $ss1 = 0 ;
   my $ss2 = 0 ;
   my $ds1 = 0 ;
   my $ds2 = 0 ;
   if (-f "tcache/$cachekey.res") {
      my $tk1 ;
      my $tk2 ;
      ($tk1, $tk2, $w1, $l1, $t, $g, $ss1, $ss2, $ds1, $ds2) =
         split " ", `cat tcache/$cachekey.res` ;
      die "Bad cache entry tcache/$cachekey.res" if !defined $ds2 ;
      $w2 = $l1 ;
      $l2 = $w1 ;
      if ($k1 ge $k2) {
         ($tk1, $tk2, $w1, $w2, $l1, $l2, $ss1, $ss2, $ds1, $ds2) =
            ($tk2, $tk1, $w2, $w1, $l2, $l1, $ss2, $ss1, $ds2, $ds1) ;
      }
      die "Key mismatch: $k1 $tk1" if ($k1 ne $tk1) ;
      die "Key mismatch: $k1 $tk1" if ($k2 ne $tk2) ;
      $games[$first] += $g ;
      $games[$second] += $g ;
      $scoresum[$first] += $ss1 ;
      $scoresum[$second] += $ss2 ;
      $deathsum[$first] += $ds1 ;
      $deathsum[$second] += $ds2 ;
      $wins[$first] += $w1 ;
      $wins[$second] += $w2 ;
      $losses[$first] += $l1 ;
      $losses[$second] += $l2 ;
      $ties[$first] += $t ;
      $ties[$second] += $t ;
   } else {
      print "./sim all $competitors[$first] $competitors[$second] 0\n" ;
      open F, "./sim all $competitors[$first] $competitors[$second] 0|"
                                or die "Can't start sim $first $second $!\n" ;
      while (<F>) {
         if (/^%s (\d+) (\d+)/) {
            my $s1 = $1 ;
            my $s2 = $2 ;
            $g++ ;
            $games[$first]++ ;
            $games[$second]++ ;
            $scoresum[$first] += $s1 ;
            $scoresum[$second] += $s2 ;
            $ss1 += $s1 ;
            $ss2 += $s2 ;
            if ($s1 > $s2) {
               $wins[$first]++ ;
               $losses[$second]++ ;
               $w1++ ;
               $l2++ ;
               print "W" ;
            } elsif ($s1 == $s2) {
               $ties[$first]++ ;
               $ties[$second]++ ;
               $t++ ;
               print "T" ;
            } else {
               $wins[$second]++ ;
               $losses[$first]++ ;
               $w2++ ;
               $l1++ ;
               print "L" ;
            }
         } elsif (/^%d (\d+) (\d+)/) {
            $deathsum[$first] += $1 ;
            $deathsum[$second] += $2 ;
            $ds1 += $1 ;
            $ds2 += $2 ;
         }
      }
      close F ;
      print "\n" ;
      open F, ">tcache/$cachekey.res" or die "Can't open tcache/$cachekey.res" ;
      if ($k1 lt $k2) {
         print F "$k1 $k2 $w1 $l1 $t $g $ss1 $ss2 $ds1 $ds2\n" ;
      } else {
         print F "$k2 $k1 $w2 $l2 $t $g $ss2 $ss1 $ds2 $ds1\n" ;
      }
      close F ;
      $matchups++ ;
      print "$competitors[$first] ($w1-$l1-$t) $competitors[$second] ($w2-$l2-$t)\n" ;
   }
   $result{"$first-$second"} = "$w1-$l1-$t" ;
   $result{"$second-$first"} = "$w2-$l2-$t" ;
}
my $i ;
mkdir "tcache" if ! -d "tcache" ;
for ($i=0; $i<$n; $i++) {
   $_ = $competitors[$i] ;
   die "Nonexistent $_" if ! -f $_ ;
   my $sum = `md5sum $_` ;
   $sum = (split " ", $sum)[0] ;
   $sum[$i] = $sum ;
   if (! -f "tcache/$sum.src") {
      open F, ">tcache/$sum.src" or die "Can't open tcache/sum.src" ;
      print F `cat $_` ;
      close F ;
   }
}
my $lastmatchups = 0 ;
sub show_standings() {
   return if $matchups == $lastmatchups ;
   $lastmatchups = $matchups ;
   my @const = sort { ((2*$wins[$b]+$ties[$b]) <=>
                       (2*$wins[$a]+$ties[$a])) ||
                      ($scoresum[$b] <=> $scoresum[$a]) } 0..$n-1 ;
   for ($i=0; $i<@const; $i++) {
      $_ = $const[$i] ;
      printf("%2d %30s (%3d-%3d-%3d) %10s\n", 1+$i, $competitors[$_], $wins[$_],
             $losses[$_], $ties[$_], $scoresum[$_]) ;
   }
   my $j ;
   print "  " ;
   for ($j=0; $j<@const; $j++) {
      printf("%11d", 1+$j) ;
   }
   printf("\n") ;
   for ($i=0; $i<@const; $i++) {
      printf("%2d", 1+$i) ;
      for ($j=0; $j<@const; $j++) {
         printf("%11s", $result{$const[$i].'-'.$const[$j]}) ;
      }
      printf("\n") ;
   }
}
for ($offset=1; $offset<$n; $offset++) {
   for ($first=0; $first<$n; $first++) {
      $second = ($first + $offset) % $n ;
      against($first, $second) ;
   }
   show_standings() ;
}
$matchups++ if ($matchups == 0) ;
show_standings() ;
