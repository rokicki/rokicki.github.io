#!/usr/bin/perl -w
#
#   Compile a .antc file into a .ant (ant state machine) file.
#
#   The format is as follows.  Note that despite the uses of braces,
#   it is *line* oriented.
#
#   Empty lines are ignored.
#   Anything following a # character is ignored.
#   Tokens must be separated by spaces.
#
#   line -> labeldef? linecontent
#   linecontent -> empty | command | controlflow | elseline | endline
#   endline -> '}'
#   elseline -> '}' 'else' '{'
#   elsefline -> '}' 'elseif' booleanexpr endcontrolflow
#   controlflow -> ('if'|'while') booleanexpr endcontrolflow
#   endcontrolflow -> '{' | command
#   booleanexpr -> '!'? basebooleanexpr
#               | '!'? basebooleanexpr '||' booleanexpr
#               | '!'? basebooleanexpr '&&' booleanexpr
#   basebooleanexpr -> 'sense' sensedir condition
#               | 'pickup'
#               | 'move'
#               | 'flip' integer
#               | 'true'
#   command -> booleanexpr
#           | 'goto' label
#           | 'mark' int6
#           | 'unmark' int6
#           | 'drop'
#           | 'turn' ('left' | 'right')
#           | 'break'
#   sensedir -> 'here' | 'ahead' | 'leftahead' | 'rightahead'
#   condition -> 'friend' | 'foe' | 'friendwithfood' | 'foewithfood' |
#                'food' | 'rock' | ('marker' i6) | 'foemarker' | 'home' |
#                'foehome'
#   int6 -> '0' | '1' | '2' | '3' | '4' | '5'
#   labeldef -> identifier ':'
#   label -> identifier
#
#   Case doesn't matter; we'll downcase throughout on initial input.  All
#   output is always lower case.
#
#   We generate output as we parse.  Each line can generate 0-2 assembly
#   statements.  At each point we have a set of sources that need to
#   point to the current target; as we number the states, we assign the
#   sources appropriately.  A source is a pair of integers; the first
#   integer is the line the source is from, and the second integer is
#   the parameter offset that needs to be assigned.
#
#   We also have a control flow stack.
#
#   For labels, we build a set of targets for each label and store them
#   in a hashtable indexed by that label; at the very end we fill them
#   all in based on the label.  The target is either 0 or 1.
#
use strict ;
my $debug = 0 ;
my $pc = 0 ; # this is the current state
my $origline = "" ;
my @tokens ;   # tokens we are parsing
my %labelpos ; # position of all labels
my %label_at_line ; # label to tag this line with
my %labelsources ; # a list of targets for each label
my $lineno = 0 ;
my @commands ; # the output commands
my @arg1 ; # the argument 1
my @arg2 ; # the argument 2
my @arg3 ; # the argument 3
my @nextstate ; # the next state (an array of arrays)
my $targets = [] ; # a ref to a list of everyone that needs to go here
#
#   The command tokens and boolean tokens.
#
my %cmdbool = (
    sense => 'b', pickup => 'b', move => 'b', flip => 'b',
    mark => 'c', unmark => 'c', drop => 'c', turn => 'c',
    goto => 'g', break => 'g', 'true' => 't', '&&' => 'l',
    '||' => 'l') ;
#
#   Print an error and die
#
sub err {
    my $errmsg = shift ;
    die "At line $lineno [$origline]:  $errmsg\n" ;
}
#
#   Control flow stack.  This is used for while and if.
#
my @stackid = () ; # stack if 'if' 'else' 'while'
my @stackpc = () ; # pc at the start
my @stackelse = () ; # targets for else condition, if any
my @stacktargs = () ; # targets for true condition, if any
my $sp = 0 ;
#
#   Push the control flow stack.
#
sub pushstack {
    my $id = shift ;
    my $origpc = shift ;
    print "Pushstack $id $origpc\n" if $debug ;
    $stackid[$sp] = $id ;
    $stackpc[$sp] = $origpc ;
    $stacktargs[$sp] = $targets ;
    $targets = [] ;
    $sp++ ;
}
#
#   Just finished a branch of a while, if or an else.
#
#   while:  set the target next states to be what's on the stack
#      (the beginning of the while); clear the target;
#      pop the target stack and join with the (now empty) current
#   if:  pop the targets and join with the current.
#   else:  pop the targets and join with the current.
#
sub settargets {
    my $targarr = shift ;
    my $targloc = shift ;
    for (@{$targarr}) {
	next if $_->[0] < 0 ;
	print "Setting target $_->[0] $_->[1] to $targloc\n" if $debug ;
	$nextstate[$_->[0]][$_->[1]] = $targloc ;
    }
}
sub findwhile {
   my $r = $sp - 1 ;
   while ($r >= 0) {
      return $r if $stackid[$r] eq 'while' ;
      $r-- ;
   }
   err "Break statement outside of while?" ;
}
sub popstack {
    my $id = shift ;
    err "Can't pop the stack (empty)" if $sp == 0 ;
    $sp-- ;
    print "Popstack $stackid[$sp]\n" if $debug ;
    if ($stackid[$sp] eq 'while') {
	settargets($targets, $stackpc[$sp]) ;
	die "Bad stackelse" if !defined($stackelse[$sp]) ;
	$targets = [@{$stackelse[$sp]}] ;
    } elsif ($stackid[$sp] eq 'if') {
	push @{$targets}, @{$stackelse[$sp]} ;
	die "Bad stackelse 2" if !defined($stackelse[$sp]) ;
    }
    push @{$targets}, @{$stacktargs[$sp]} ;
}
#
#   Check an argument against a set of conditions.
#
sub checkarg {
    my $arg = shift @tokens ;
    my $opts = shift ;
    my @opts = split /\|/, $opts ;
    for (@opts) {
	return $arg if $arg eq $_ ;
    }
    err "Expected one of @opts but got $arg" ;
}
#
#   Pick up arguments for this command.
#
sub pickupargs {
    my $id = shift ;
    if ($id eq 'sense') {
	err "Need two arguments for sense" if @tokens < 2 ;
	$arg1[$pc] = checkarg('here|ahead|leftahead|rightahead') ;
	$arg2[$pc] = checkarg('friend|foe|friendwithfood|foewithfood|food|rock|marker|foemarker|home|foehome') ;
	if ($arg2[$pc] eq 'marker') {
	    err "Need argument to marker condition" if @tokens < 1 ;
	    $arg3[$pc] = checkarg('0|1|2|3|4|5') ;
	}
    } elsif ($id eq 'flip') {
	err "Need argument for $id" if @tokens < 1 ;
	err "Expected an integer" if $tokens[0] !~ /^[1-9][0-9]*$/ ;
	$arg1[$pc] = shift @tokens ;
    } elsif ($id eq 'mark' || $id eq 'unmark') {
	err "Need argument for $id" if @tokens < 1 ;
	$arg1[$pc] = checkarg('0|1|2|3|4|5') ;
    } elsif ($id eq 'turn') {
	err "Need argument for $id" if @tokens < 1 ;
	$arg1[$pc] = checkarg('left|right') ;
    }
}
#
#   Do all the real work
#
if (@ARGV) {
   my $filename = shift ;
   my $output_filename = $filename ;
   if ($output_filename =~ /\./) {
      $output_filename =~ s/.antc$/.ant/g or
                                     die "Input file name must end in antc" ;
      open STDIN, "$filename" or die "Can't open $filename" ;
   } else {
      die "Can't open $filename.antc" if !-f "$filename.antc" ;
      open STDIN, "$filename.antc" ;
      $output_filename .= ".ant" ;
   }
   open STDOUT, ">$output_filename" or die "Couldn't open $output_filename" ;
}
sub updatelabels {
   for (keys %labelpos) {
      if ($labelpos{$_} == $pc) {
         err "Cannot have a label immediately preceding a goto" ;
      }
   }
}
#
#   Preprocess.
#
open M4, "|m4 -I ./ants >tmp.m4" or die "Can't open tmp.m4 for writing" ;
while (<>) {
   print M4 $_ ;
}
close M4 ;
open STDIN, "tmp.m4" or die "Can't open tmp.m4 for reading" ;
while (<>) {
    $lineno++ ;
    chomp ;
    $origline = $_ ; # what we are parsing
    $origline =~ s/\s*$// ;
    s/#.*//g ; # comments
    s/\s*;\s*$//g ; # allow and ignore trailing semicolons
    $_ = lc $_ ; # lower case everything
    my @sublines = split ";", $_ ;
   for (@sublines) {
    @tokens = split " ", $_ ;
    next if 0 == @tokens ;
    # check for a label
    if ($tokens[0] =~ /^(.*):$/) {
	shift @tokens ;
	my $label = $1 ;
	err "Label $label already defined" if $labelpos{$label} ;
	$labelpos{$label} = $pc ;
	$label_at_line{$pc}= $label ;
    }
    next if 0 == @tokens ;
    my $ifwhile = '' ;
    my @truetargs = () ;
    my @falsetargs = () ;
    my $elseiftargets = undef ;
    if ($tokens[0] eq '}') { # either '}' or '} else {'
        updatelabels('close brace') ;
	if (@tokens == 1) {
	    popstack('') ;
            next ;
	} elsif (@tokens == 3 && $tokens[1] eq 'else' && $tokens[2] eq '{') {
	    err "Can't use } before if or while" if $sp <= 0 ;
	    err "Can't use else with anything but if"
		                                  if $stackid[$sp-1] ne 'if' ;
	    push @{$stacktargs[$sp-1]}, @{$targets} ;
	    $stackid[$sp-1] = 'else' ;
	    $targets = [@{$stackelse[$sp-1]}] ;
            next ;
        } elsif (@tokens > 3 && $tokens[1] eq 'elseif') {
	    err "Can't use elseif with anything but if"
		                                  if $stackid[$sp-1] ne 'if' ;
	    push @{$stacktargs[$sp-1]}, @{$targets} ;
            $elseiftargets = $targets ;
            $targets = [@{$stackelse[$sp-1]}] ;
            $ifwhile = 'if' ;
            shift @tokens ;
            shift @tokens ;
	} else {
	    err "Unrecognized line beginning with }" ;
	}
    }
    if ($tokens[0] eq 'if' || $tokens[0] eq 'while') { # conditional
	$ifwhile = $tokens[0] ;
	shift @tokens ;
	err "No expr in if or while" if !@tokens ;
    }
    #
    #   Now we have to have either a boolean or a command.
    #   We do not allow a command if $ifwhile is not true.
    #   On the other hand, if $ifwhile is true, we pick up a
    #   boolean, push the stack, and then continue for a
    #   potential command if the next token isn't '{'.
    #
    my $oldifwhile = $ifwhile ;
    my $origpc = $pc ;
    while (1) {
        my $invertif = 0 ;
        if ($ifwhile) {
           if (@tokens && $tokens[0] eq '!') {
              $invertif = 1 ;
              shift @tokens ;
           }
           err "No expr in if or while" if !@tokens ;
        }
	my $tok = $tokens[0] ;
	my $cmdbool = $cmdbool{$tok} ;
	err "Unrecognized command" if !$cmdbool ;
	err "Cannot use true as command" if $cmdbool eq 't' && !$ifwhile ;
	err "Cannot use command as boolean" if $cmdbool eq 'c' && $ifwhile ;
	shift @tokens ;
        if ($cmdbool eq 'l') {
           err "Cannot use && or || outside of boolean context" ;
        }
	if ($cmdbool eq 'c' || $cmdbool eq 'b') { # we will emit a command
	    settargets($targets, $pc) ;
	    $targets = [] ;
	    print "Adding command $tok\n" if $debug ;
	    $commands[$pc] = $tok ;
	    pickupargs($tok) ;
	    if ($cmdbool eq 'c') { # command, just one target
		print "Adding a single one to targets\n" if $debug ;
		push @{$targets}, [$pc, 0] ;
	    } elsif (!$ifwhile) { # two targets; set both
		print "Adding a double to targets\n" if $debug ;
		push @{$targets}, [$pc, 0], [$pc, 1] ;
	    }
	    $pc++ ;
	} elsif ($cmdbool eq 'g') { # goto
           updatelabels('goto') ;
           if ($tok eq 'goto') {
	       err "Need label for goto" if @tokens == 0 ;
	       my $lab = shift @tokens ;
	       push @{$labelsources{$lab}}, @{$targets} ;
	       $targets = [] ;
           } elsif ($tok eq 'break') {
               updatelabels('break') ;
               my $i = findwhile() ;
               push @{$stacktargs[$i]}, @{$targets} ;
               $targets = [] ;
           }
	}
	if ($ifwhile) {
	    err "Expected { or command after condition" if !@tokens ;
            if ($cmdbool eq 'b') {
               push @truetargs, [$pc-1, $invertif] ;
               push @falsetargs, [$pc-1, 1-$invertif] ;
            } else { # true
               push @truetargs, @{$targets} ;
            }
            $targets = [] ;
            if ($tokens[0] eq '&&' || $tokens[0] eq '||') {
               my $log = shift @tokens ;
	       err "Expected boolean after condition" if !@tokens ;
               if ($log eq '&&') {
                  push @{$targets}, @truetargs ;
                  @truetargs = () ;
               } else {
                  push @{$targets}, @falsetargs ;
                  @falsetargs = () ;
               }
            } else {
               $targets = [] ;
               pushstack($ifwhile, $origpc) if ! $elseiftargets ;
	       push @{$targets}, @truetargs ;
	       $stackelse[$sp-1] = [@falsetargs] ;
	       $ifwhile = '' ;
	       if ($tokens[0] eq '{') {
  	          shift @tokens ;
	          last ;
	       }
            }
	} else {
	    popstack('') if $oldifwhile ;
	    last ;
	}
    }
    err "Unexpected token $tokens[0] after valid line" if @tokens > 0 ;
   }
}
err "Program ended with control flow stack non-empty" if $sp != 0 ;
err "Program fell off the end (control flow)" if @{$targets} > 0 ;
my $label ;
for $label (keys %labelsources) {
    err "Label $label not defined" if !defined($labelpos{$label}) ;
    settargets($labelsources{$label}, $labelpos{$label}) ;
}
#
#   Now emit the program.
#
my $i ;
#
for ($i=0; $i<@commands; $i++) {
    print $commands[$i] ;
    print " $arg1[$i]" if defined($arg1[$i]) ;
    print " $nextstate[$i][0]" if defined($nextstate[$i][0]) ;
    print " $nextstate[$i][1]" if defined($nextstate[$i][1]) ;
    print " $arg2[$i]" if defined($arg2[$i]) ;
    print " $arg3[$i]" if defined($arg3[$i]) ;
#   print " ; state $i\n" ;
    print " ; $label_at_line{$i}" if defined($label_at_line{$i}) ;
    print "\n" ;
    warn "Internal error 1 at command $i $commands[$i]"
	if !defined($nextstate[$i][0]) ;
    warn "Internal error 2 at command $i $commands[$i]"
	if $cmdbool{$commands[$i]} eq 'b' && !defined($nextstate[$i][1]) ;
}
