#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctype.h>

int maxline=-1;
int maxref=-1;

void error(char *s) {
	fprintf(stderr,"%d: %s\n",maxline,s);
	exit(1);
}

int m(char *s, char *t) {
	return !strcasecmp(s,t);
}

void sensedir(char *s) {
	if (!m(s,"here") && !m(s,"ahead") && !m(s,"leftahead")
	    && !m(s,"rightahead")) error("sensedir");
}

void cond(char *s) {
	if (!m(s,"friend") && !m(s,"foe") && !m(s,"friendwithfood")
	    && !m(s,"foewithfood") && !m(s,"food") && !m(s,"rock")
	    && !m(s,"foemarker") && !m(s,"foehome") && !m(s,"home")) error("cond");
}

void lr(char *s) {
	if (!m(s,"left") && !m(s,"right")) error("lr");
}

void marknum(char *s) {
	if (!m(s,"0") &&
	!m(s,"1") &&
	!m(s,"2") &&
	!m(s,"3") &&
	!m(s,"4") &&
	!m(s,"5")) error("lr");
}

void p(char *s) {
	int i;
	for(i=0;s[i];i++) {
		if (!isdigit(s[i])) error("p");
	}
	if (!s[0] || atoi(s)<=0) error("p");
}

void state(char *s) {
	int i;
	for(i=0;s[i];i++) {
		if (!isdigit(s[i])) error("st");
	}
	if (!s[0] || atoi(s)<0) error("st");
	maxref >?= atoi(s);
}

void checkst(void) {	
	if (maxref>maxline) error("reference");
}

void end(char *s) {
	if (s) error("line length");
}


char buf[1000];
int main(int argc, char *argv[]) {
	
	FILE *inf;
	inf=fopen(argv[1],"r");
	
	while(fgets(buf,900,inf)) {
		for(int i=0;buf[i];i++) if (buf[i]==';') { buf[i]=0; break; }
		char *s=strtok(buf," \t\n\r");
		
#define next if(s) s=strtok(0," \t\n\r")
		maxline++;

		if (!s) error("empty line");

		if (m(s,"sense")) {
			next;
			sensedir(s);
			next;
			state(s);
			next;
			state(s);
			next;
			if (m(s,"marker")) {
				next;
				marknum(s);
			} else
				cond(s);
			next;
			end(s);
		} else 
		if (m(s,"mark")) {
			next;
			marknum(s);
			next;
			state(s);
			next;
			end(s);
		} else
		if (m(s,"unmark")) {
			next;
			marknum(s);
			next;
			state(s);
			next;
			end(s);
		} else
		if (m(s,"pickup")) {
			next;
			state(s);
			next;
			state(s);
			next;
			end(s);		
		} else
		if (m(s,"drop")) {
			next;
			state(s);
			next;
			end(s);		
		} else
		if (m(s,"turn")) {
			next;
			lr(s);
			next;
			state(s);
			next;
			end(s);		
		} else
		if (m(s,"move")) {
			next;
			state(s);
			next;
			state(s);
			next;
			end(s);		
		} else
		if (m(s,"flip")) {
			next;
			p(s);
			next;
			state(s);
			next;
			state(s);
			next;
			end(s);		
		} else error("instruction");
	}
	checkst();
	fprintf(stderr,"OK\n");
	return 0;	
}
















