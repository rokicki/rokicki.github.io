import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
/* The trace should contain a number of lines, one for each activity, in order
 * Each line should contain a number of space separated tokens.
 * The first token should be an integer, representing the ant ID.
 * The next token should be a string, representing the ant's action.
 * Valid actions are: move, turn, pickup, drop, die, mark, unmark
 * mark and unmark should be followed by an integer, representing the thing to mark or unmark
 * turn should be followed by an l or r
 */
public class AntSim extends Frame{
    static int x = -1, y = -1;
    public static void main(String[] a){
        if(a.length!=3 && a.length!=2){
            System.out.println("Usage: java Ant <trace filename> <gridSize> <go?>");
            return;
        }
        final AntSim f = new AntSim();
        f.size = Double.parseDouble(a[1]);
        f.initializeWorld(a[0]);
        final Controls con = new Controls(f, a.length==3&&a[2].equals("1")?true:false);
        final Label info = new Label();
        f.add(con,"South");
        f.add(info,"North");
        f.addKeyListener(new KeyAdapter(){
            public void keyPressed(KeyEvent ke){
                char c = ke.getKeyChar();
                if(c=='='){
                    f.size++;
                    f.reset();
                }else if (c=='-'){
                    f.size--;
                    f.reset();
                }
            }
        });
        f.addMouseMotionListener(new MouseMotionAdapter(){
            public void mouseDragged(MouseEvent me){
                f.offx+=me.getX()-x;
                f.offy+=me.getY()-y;
                x = me.getX();
                y = me.getY();
                f.reset();
                f.repaint();
            }
            public void mouseMoved(MouseEvent me){
                if(!con.going){
                    double x = (me.getX() - f.offx)/f.size/f.r3;
                    double y = Math.round((me.getY() - f.offy)/f.size/3*2 - .5);
                    if(y%2==1){
                        x -= 1.0 / 2;
                    }
                    x = Math.round(x);
                    info.setText(f.display((int)x, (int)y));
                }
            }
        });
        f.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent me){
                x = me.getX();
                y = me.getY();
            }
        });
        f.setSize(1000,700);
        f.setVisible(true);
    }
    String marks(int n){
        String s = "";
        for(int i = 0; (1<<i)<=n; i++){
            if((n&(1<<i)) > 0){
                s+=i;
            }
        }
	s+= " (";
        for(int i = 0; i<6; i++){
            if((n&(1<<i)) > 0){
                s+='1';
            } else {
		s+='0';
	    }
        }
	s+= ")";
        return s;
    }
    String display(int x, int y){
        if(world==null)return "";
        if(x >= world[0].length || x<0)return "";
        if(y >= world.length || y<0)return "";
        String s = "At ("+x+","+y+"), "+world[y][x]+" food present. - ";
        s += "Team 0 has scents "+marks((mark[y][x]&63))+". - ";
        s += "Team 1 has scents "+marks((mark[y][x]>>6)&63)+". - ";
        for(int i = 0; i<id; i++){
            if(ants[i].x == x && ants[i].y == y){
                s+="Ant "+i+" is present, and is "+(ants[i].hasFood?"":"not ")+"carrying food.";
            }
        }
        return s;
    }
    int[] score = new int[2];
    int[] steals = new int[2];
    int[][] world;
    int[][] hill;
    int[][] mark;
    boolean[][] colored;
    boolean[][] clear;
    double r3 = Math.sqrt(3);
    int offx = 5, offy = 30;
    double size = 10;
    void reset(){
        for(int i =0 ; i<clear.length; i++)
            for(int j =0 ; j<clear[0].length; j++)
                clear[i][j] = true;
    }
    boolean byMe = false;
    public void update(Graphics g){
	byMe = true;
	paint(g);
    }
    public synchronized void forcepaint() {
	repaint();
	try {
	    wait();
	} catch (InterruptedException e) {}
    }
    public synchronized void paint(Graphics g){
        for(int i = 0; i<colored.length; i++){
            for(int j = 0; j<colored[i].length; j++)
                colored[i][j] = false;
        }
        if(!byMe)reset();
        byMe = false;
        for(int i = 0; i<world.length; i++){
            for(int j = 0; j<world[0].length; j++){
                if(!clear[i][j])continue;
                if(hill[i][j] != 0){
                    colored[i][j] = true;
                    if(hill[i][j] == 1)
                        fill(g,j,i,new Color(200,200,255));
                    else
                        fill(g,j,i,new Color(255,200,200));
                    clear[i][j] = false;
                }
                if(mark[i][j] != 0){
                    colored[i][j] = true;
                    if (mark[i][j] == 1)
                        fill(g,j,i,new Color(255,0,255));
                    else if (mark[i][j] == 2)
                        fill(g,j,i,new Color(0,255,0));		   
                    else if (mark[i][j] == 4)
                        fill(g,j,i,new Color(255,0,128));
                    else if (mark[i][j] == 8)
                        fill(g,j,i,new Color(0,255,128));
                    else if (mark[i][j] == 16)
                        fill(g,j,i,new Color(255,128,128));
                    else if (mark[i][j] == 32)
                        fill(g,j,i,new Color(255,255,128));
                    else if (mark[i][j] < 64)
                        fill(g,j,i,new Color(Math.min(255,4*mark[i][j]),0,Math.min(255,4*mark[i][j])));
                    else
                        fill(g,j,i,new Color(128,128,128));
                    clear[i][j] = false;
                }
                if(world[i][j] == -1){
                    colored[i][j] = true;
                    fill(g,j,i,Color.black);
                    clear[i][j] = false;
                }else if(world[i][j]!=0){
                    colored[i][j] = true;
                    fill(g,j,i,new Color(128,Math.min(255,world[i][j] * 30),0));
                    clear[i][j] = false;
                }
            }
        }
        for(int i = 0; i<id; i++){
            if(!ants[i].dead && (clear[ants[i].y][ants[i].x] || colored[ants[i].y][ants[i].x])){
                boolean t = ants[i].type==0;
                Color col = new Color(t?0:255,ants[i].hasFood?130:0,t?255:0);
                fill(g,ants[i].x,ants[i].y,col);
                dot(g,ants[i].x,ants[i].y,ants[i].dir,Color.black);
                clear[ants[i].y][ants[i].x] = false;
                colored[ants[i].y][ants[i].x] = true;
            }
        }
        for(int i = 0; i<world.length; i++){
            for(int j = 0; j<world[0].length; j++){
                if(!colored[i][j])continue;
                if(mark[i][j]!=0){
                    center(g,j,i,Color.gray);
                    clear[i][j] = false;
                }
                if(world[i][j]>0){
                    center(g,j,i,new Color(128,Math.min(255,world[i][j] * 30),0));
                    clear[i][j] = false;
                }
            }
        }
        for(int i = 0; i<clear.length; i++){
            for(int j = 0; j<clear[0].length; j++){
                if(clear[i][j]){
                    colored[i][j] = true;
                    fill(g,j,i,Color.white);
                    clear[i][j] = false;
                }
            }
        }
        g.setColor(Color.black);
        for(int i = 0; i<world.length; i++){//y
            for(int j = 0; j<world[0].length; j++){//x
                if(i==0 || j==0)continue;
                if(i==world.length-1 || j==world[0].length-1)continue;
                boolean recolor = false;
                if(colored[i][j])recolor = true;
                if(i%2==0 && (colored[i-1][j] || colored[i+1][j]))recolor = true;
                if(i%2==1 && (colored[i-1][j+1] || colored[i+1][j+1]))recolor = true;
                if(colored[i][j+1])recolor = true;
                if(!recolor)continue;
//                System.out.println(i+" "+j+" "+colored[i][j]);
                double tx = size * r3 * j+offx;
                if(i%2==1){
                    tx += size * r3 / 2;
                }
                double ty = 3 * size / 2 * i +offy;
                double x1 = tx + r3*size/2;
                double y1 = ty + size/2;
                double x2 = x1;
                double y2 = y1 + size;
                double x3 = tx;
                double y3 = ty + 2 * size;
                g.drawLine((int)Math.round(tx), (int)Math.round(ty), (int)Math.round(x1), (int)Math.round(y1));
                g.drawLine((int)Math.round(x1), (int)Math.round(y1), (int)Math.round(x2), (int)Math.round(y2));
                g.drawLine((int)Math.round(x2), (int)Math.round(y2), (int)Math.round(x3), (int)Math.round(y3));
            }
        }
	notifyAll();
    }
    void dot(Graphics g, int x, int y, int dir, Color c){
        double tx = size * r3 * x+offx;
        if(y%2==1){
            tx += size * r3 / 2;
        }
        double ty = 3 * size / 2 * y + offy + size;
        double ang = Math.PI / 3 * dir;
        tx += Math.cos(ang) * r3*(size-2)/2;
        ty += Math.sin(ang) * r3*(size-2)/2;
        g.setColor(c);
        g.fillOval((int)Math.round(tx-1), (int)Math.round(ty-1),2,2);
    }
    void fill(Graphics g, int x, int y, Color c){
        double tx = size * r3 * x+offx;
        if(y%2==1){
            tx += size * r3 / 2;
        }
        double ty = 3 * size / 2 * y +offy;
        double ang = Math.PI/6;
        int[] xp = new int[6];
        int[] yp = new int[6];
        xp[0] = (int)Math.round(tx);
        yp[0] = (int)Math.round(ty);
        for(int i = 1; i<6; i++){
            tx += Math.cos(ang) * size;
            ty += Math.sin(ang) * size;
            ang += Math.PI/3;
            xp[i] = (int)Math.round(tx);
            yp[i] = (int)Math.round(ty);
        }
        g.setColor(c);
        g.fillPolygon(xp,yp,6);
    }
    void center(Graphics g, int x, int y, Color c){
        double tx = size * r3 * x+offx;
        if(y%2==1){
            tx += size * r3 / 2;
        }
        double ty = 3 * size / 2 * y + offy + size;
        g.setColor(c);
        g.fillOval((int)Math.round(tx-size/3), (int)Math.round(ty-size/3),(int)Math.round(2*size/3+1),(int)Math.round(2*size/3+1));
    }
    boolean going;
    int sims = 0;
    int rounds = 0;
    //type 0 means GO, type 1 means step, type 2 means step to round
    public synchronized int simulate(){
        try{
            String tok = t.getToken();
            if(tok == null)return -1;
            int ID = Integer.parseInt(tok);
            if(ID==-1){
                rounds ++ ;
                return 0;
            }
            tok = t.getToken();
            if(tok.equalsIgnoreCase("move")){
                ants[ID].move();
            }else if(tok.equalsIgnoreCase("turn")){
                ants[ID].turn(t.getToken());
            }else if(tok.equalsIgnoreCase("drop")){
                ants[ID].drop();
            }else if(tok.equalsIgnoreCase("pickup")){
                ants[ID].pickup();
            }else if(tok.equalsIgnoreCase("mark")){
                ants[ID].mark(Integer.parseInt(t.getToken()));
            }else if(tok.equalsIgnoreCase("unmark")){
                ants[ID].unmark(Integer.parseInt(t.getToken()));
            }else if(tok.equalsIgnoreCase("die")){
                ants[ID].die();
            }
            sims++;
            return 1;
        }catch(Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    int id = 0;
    Ant[] ants = new Ant[1000];
    void addAnt(int type, int x, int y){
        hill[y][x] = type+1;
        ants[id] = new Ant(id,type,x,y,0);
        id++;
    }
    Tokenizer t;
    void initializeWorld(String w) {
        try{
            if (w.equals("-")) {
               t = new Tokenizer(new BufferedReader(new InputStreamReader(System.in)));
            } else {
               t = new Tokenizer(new BufferedReader(new FileReader(w)));
            }
        }catch(Exception e){
            e.printStackTrace();
            return;
        }
        int x = Integer.parseInt(t.getToken());
        int y = Integer.parseInt(t.getToken());
        world = new int[y][x];
        hill = new int[y][x];
        clear = new boolean[y][x];
        colored = new boolean[y][x];
        mark = new int[y][x];
        for(int i = 0; i<y; i++){
            for(int j = 0; j<x; j++){
                char c = t.getToken().charAt(0);
                switch(c){
                    case '#':
                        world[i][j] = -1;
                        break;
                    case '-':
                        addAnt(0,j,i);
                        break;
                    case '+':
                        addAnt(1,j,i);
                    case '.':
                        break;
                    default:
                        world[i][j] = c-'0';
                }
            }
        }
    }
    class Tokenizer{
        String[] line = new String[0];
        int idx = 0;
        BufferedReader br;
        Tokenizer(BufferedReader br){
            this.br = br;
        }
        String getToken(){
            try{
                while(idx >= line.length){
                    idx = 0;
                    String s = br.readLine();
                    if(s==null)return null;
                    line = s.trim().split(" +");
                }
                return line[idx++];
            }catch(Exception e){
                e.printStackTrace();
                return null;
            }
        }
    }
    class Ant{
        int i, type, x, y, dir;
        boolean dead = false;
        boolean hasFood = false;
        Ant(int i, int type, int x, int y, int dir){
            this.i = i;
            this.type = type;
            this.x = x;
            this.y = y;
            this.dir = dir;
        }
        void move(){
            clear[y][x] = true;
            int oy = y;
            int ox = x;
            switch(dir){
                case 0: x++; break;
                case 1: if (y%2==0){ y++; }else{ x++; y++; } break;
                case 2: if (y%2==0){ x--; y++; } else { y++; } break;
                case 3: x--; break;
                case 4: if (y%2==0) { x--; y--; } else { y--; } break;
                case 5: if (y%2==0) { y--; }else { x++; y--; } break;
            }
            for(int j = 0; j<id; j++){
                if(!ants[j].dead && ants[j].x == x && ants[j].y == y && ants[j].i != this.i){
                    System.out.println("Warning: ant "+i+" tried to move onto an occupied cell.  Instruction " + sims+". ("+ox+","+oy+") to ("+x+","+y+"), dir="+dir);
                    x = ox;
                    y = oy;
                    return;
                }
            }
            if(world[y][x] == -1){
                x = ox;
                y = oy;
                System.out.println("Warning: ant "+i+" tried to move onto a rock at ("+y+","+x+"). Instruction "+sims);
                return;
                
            }
            clear[y][x] = true;
        }
        void turn(String s){
            clear[y][x] = true;
            if(s.equalsIgnoreCase("l")){
                dir = (dir + 5) % 6;
            }else if(s.equalsIgnoreCase("r")){
                dir = (dir + 1) % 6;
            }else{
                System.out.println("Error: ant "+i+" expected to turn l or r, got: "+s+". Instruction "+sims);
            }
        }
        void drop(){
            if(!hasFood){
                System.out.println("Error: ant "+i+" can't drop at ("+x+","+y+"), no food carried. Instruction "+sims);
            }else{
                if(hill[y][x] > 0){
                    score[hill[y][x]-1]++;
                }
                hasFood = false;
                world[y][x] ++;
                clear[y][x] = true;
            }
        }
        void pickup(){
            if(world[y][x] <= 0){
                System.out.println("Error: ant "+i+" can't pick up at ("+x+","+y+"), no food present. Instruction "+sims);
            }else if(hasFood){
                System.out.println("Warning: ant "+i+" can't pick up at ("+x+","+y+"), alread has food. Instruction "+sims);
            }else{
                if(hill[y][x] > 0){
                    score[hill[y][x]-1]--;
                    if(type!=hill[y][x]-1){
                        steals[type]++;
                    }
                }
                hasFood = true;
                world[y][x] --;
                clear[y][x] = true;
            }
        }
        void mark(int m){
            if(m < 0 || m > 5){
                System.out.println("Error: ant "+i+" can't mark type: "+m);
            }else{
                mark[y][x] |= (1<<m)<<(type*6);
                clear[y][x] = true;
            }
        }
        void unmark(int m){
            if(m < 0 || m > 5){
                System.out.println("Error: ant "+i+" can't unmark type: "+m);
            }else{
                mark[y][x] &= ~((1<<m)<<(type*6));
                clear[y][x] = true;
            }
        }
        void die(){
            if(dead){
                System.out.println("Error: ant "+i+" can't die, already dead. Instruction "+sims);
            }else{
                dead = true;
                world[y][x] += 3;
                if(hasFood)world[y][x]++;
                clear[y][x] = true;
            }
        }
    }
}
class Controls extends Panel{
    final AntSim as;
    final TextField delay,dist;
    final Label status;
    boolean going;
    public Controls(AntSim a,boolean start){
        as = a;
        Button next = new Button(">");
        Button nextRound = new Button(">>");
        Button go = new Button("GO");
        Button skip = new Button("Skip");
        dist = new TextField("100");
        Button stop = new Button("Stop");
        Button in = new Button("+");
        Button out = new Button("-");
        delay = new TextField("-100");
        status = new Label("0 instructions performed, round 0.  Score: 0-0"+".  Steals:"+as.steals[0]+"-"+as.steals[1]);
        setLayout(new FlowLayout());
        add(in);
        add(out);
        add(next);
        add(nextRound);
        add(go);
        add(stop);
        add(new Label("Delay:"));
        add(delay);
        add(skip);
        add(dist);
        add(status);
        next.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                while(as.simulate() == 0);
                status.setText(as.sims+" instructions performed, round "+as.rounds+".  Score: "+as.score[0]+"-"+as.score[1]+".  Steals:"+as.steals[0]+"-"+as.steals[1]);
                as.repaint();
                
            }
        });
        nextRound.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try{
                    while(as.simulate() == 1){
                        status.setText(as.sims+" instructions performed, round "+as.rounds+".  Score: "+as.score[0]+"-"+as.score[1]+".  Steals:"+as.steals[0]+"-"+as.steals[1]);
                        as.byMe = true;
                        as.repaint();
                        Thread.sleep(Integer.parseInt(delay.getText()));
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        skip.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try{
                    int d = Integer.parseInt(dist.getText());
                    for(int i = 0; i<d && as.simulate() != -1; i++){
                        status.setText(as.sims+" instructions performed, round "+as.rounds+".  Score: "+as.score[0]+"-"+as.score[1]+".  Steals:"+as.steals[0]+"-"+as.steals[1]);
                    }
                    as.repaint();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        go.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try{
                    going = true;
                    new DoSim(as).start();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        in.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                as.size++;
                as.reset();
            }
        });
        out.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                as.size--;
                as.reset();
            }
        });
        stop.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                going = false;
            }
        });
        if(start){
            going = true;
            new DoSim(as).start();
        }
    }
    class DoSim extends Thread{
        AntSim as;
        DoSim(AntSim as){
            this.as = as;
        }
        public void run(){
            int countdown = 0 ;
            while(going){
                int idelay = Integer.parseInt(delay.getText()) ;
                if(as.simulate()==-1)going = false;
                countdown-- ;
                if (countdown <= 0)
                    status.setText(as.sims+" instructions performed, round "+as.rounds+".  Score: "+as.score[0]+"-"+as.score[1]+".  Steals:"+as.steals[0]+"-"+as.steals[1]);
                if (idelay >= 0 || countdown <= 0) {
                    as.forcepaint();
                    if (idelay > 0) {
                        try{
                            Thread.sleep(idelay) ;
                        }catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                    if (countdown <= 0 && idelay < 0)
                        countdown = - idelay ;
                }
            }
        }
    }
}
