#!/usr/local/bin/perl -w
#
#   I need netcat-like functionality a lot, but it's so hard to find
#   precompiled so this is a really dumb netcat-like program in Perl.
#
#   Usage:
#
#   perl pnc.pl filename [hostname:]portnum   sends files
#   perl pnc.pl [hostname:]portnum filename   receives files
#
#   If filename is - uses stdin.  If no hostname is given, it opens
#   a server socket with that port.  If hostname is given, it attempts
#   to connect to the port on that host.  Does not support filenames
#   that are numbers or that end in : followed by a number.
#
#   Written by Tomas Rokicki.
#
use strict ;
use Socket ;
use Carp ;
sub usage() {
   print STDERR "Usage:  perl pnc.pl filename [hostname:]portnum\n" ;
   print STDERR "        perl pnc.pl [hostname:]portnum filename\n" ;
   exit(10) ;
}
usage() if (@ARGV != 2) ;
sub parse {
   my $fn = shift ;
   my $typ = shift ;
   if ($fn eq '-') { # stdin, stdout
      if ($typ eq 'r') {
         *FIN = *STDIN ;
      } else {
         *FOUT = *STDOUT ;
      }
   } elsif ($fn =~ /^[0-9]*$/) {
      my $port = $fn ;
      my $proto = getprotobyname('tcp') ;
      socket(Server, PF_INET, SOCK_STREAM, $proto) or die "socket: $!" ;
      setsockopt(Server, SOL_SOCKET, SO_REUSEADDR, pack("l", 1))
                                                    or die "setsockopt: $!" ;
      bind(Server, sockaddr_in($port, INADDR_ANY)) or die "bind: $!" ;
      listen(Server, SOMAXCONN) or die "listen: $!" ;
      if ($typ eq 'r') {
         accept(FIN, Server) ;
      } else {
         accept(FOUT, Server) ;
      }
   } elsif ($fn =~ /:[0-9]+$/) {
      my ($hostname, $port) = split ':', $fn ;
      my $iaddr = inet_aton($hostname) or die "no host: $hostname" ;
      my $paddr = sockaddr_in($port, $iaddr) ;
      my $proto = getprotobyname('tcp') ;
      if ($typ eq 'r') {
         socket(FIN, PF_INET, SOCK_STREAM, $proto) or die "socket: $!" ;
         connect(FIN, $paddr) or die "connect: $!" ;
      } else {
         socket(FOUT, PF_INET, SOCK_STREAM, $proto) or die "socket: $!" ;
         connect(FOUT, $paddr) or die "connect: $!" ;
      }
   } else { # file name
      if ($typ eq 'r') {
         open FIN, "$fn" or die "Couldn't open $fn for reading" ;
      } else {
         open FOUT, ">$fn" or die "Couldn't open $fn for writing" ;
      }
   }
   if ($typ eq 'r') {
      binmode FIN ;
   } else {
      binmode FOUT ;
   }
}
parse($ARGV[0], 'r') ;
parse($ARGV[1], 'w') ;
while (1) {
   my $r=sysread(FIN, $a, 4096) ;
   if (!defined($r)) {
      print STDERR "Read error? $!\n" ;
      exit(10) ;
   }
   print STDERR "#" ;
   last if $r <= 0 ;
   my $off = 0 ;
   while ($off < $r) {
      my $w = syswrite(FOUT, $a, 4096-$off, $off) ;
      if (!defined($w)) {
         print STDERR "Write error? $!\n" ;
         exit(10) ;
      }
      $off += $w ;
   }
}
close FIN ;
close FOUT ;
