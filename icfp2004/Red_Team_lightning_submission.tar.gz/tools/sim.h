// simulator header file.   jcd

struct pos { pos(int a, int b) {x=a,y=b;} pos(void) { x=0,y=0; } int x,y; };
typedef int dir;

enum lor { left,right };
enum sense_dir { here,ahead,lahead,rahead };
enum col { red,black };
struct ant {
	ant(void) { }
	int id;
	col colour;
	int state;
	int resting;
	dir d;
	int has_food;
	int alive;
	pos p;
};

struct cell {
	int ant;
	int food;
	int redmark;
	int blackmark;
	int rock;
	int redhill;
	int blackhill;
};

enum condition {
	fr,foe,frfood,foefood,food,rock,mark0,mark1,mark2,mark3,mark4,mark5,foemark,
	home,foehome };

enum instype {
	sense,mark,unmark,pickup,drop,iturn,move,flip
};

struct inst {
	instype t;
	dir d;
	sense_dir sd;
	lor lr;
	int st0,st1;
	condition cond;	
	int flipint;
	int marker;
};


// Global variables

inst prog[2][11000];
int proglen[2];

FILE *tfile;

cell world[1000][1000];
int X,Y;

ant ants[400];
int A;

int stepnumber=0;
int dotrace;
int flipped=0;

int global_score_red,global_score_black;

