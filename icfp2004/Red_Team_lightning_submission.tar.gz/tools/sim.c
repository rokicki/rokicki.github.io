// ants simulator.   jcd
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

#include "sim.h"


void trace(int x) {
	if (tfile) fprintf(tfile,"%d ",x);
}

void trace(char *b) {
	if (tfile) fprintf(tfile,"%s ",b);
}
void tracel(void) {
	if (tfile) fprintf(tfile,"\n");
}

void warn(char *s) { fprintf(stderr,"%s\n",s); return; }

pos adjacent_cell(pos p, dir d) {
	int x=p.x,y=p.y;
	switch(d) {
		case 0:return pos(x+1,y);
		case 1:return (y%2)?pos(x+1,y+1):pos(x,y+1);
		case 2:return (y%2)?pos(x,y+1):pos(x-1,y+1);
		case 3:return pos(x-1,y);
		case 4:return (y%2)?pos(x,y-1):pos(x-1,y-1);
		case 5:return (y%2)?pos(x+1,y-1):pos(x,y-1);
		default:warn("invalid direction"); return p;
	}
}


dir turn(lor f, dir d) {
	if(f==left) return (d+5)%6; return (d+1)%6;
}


pos sensed_cell(pos p, dir d, sense_dir sd) {
	switch(sd) {
		case here:return p;
		case ahead:return adjacent_cell(p,d);
		case lahead:return adjacent_cell(p,turn(left,d));
		case rahead:return adjacent_cell(p,turn(right,d));
	}
	warn("sensed_cell");
	return p;
}


col other_col(col c) { return c==red?black:red; }



int rocky(pos p) { return world[p.x][p.y].rock; }

int some_ant_is_at(pos p) { return world[p.x][p.y].ant!=-1; }
int ant_at(pos p) { return world[p.x][p.y].ant; }
void set_ant_at(pos p, int a) { world[p.x][p.y].ant=a; }
void clear_ant_at(pos p) { world[p.x][p.y].ant=-1; }

int ant_is_alive(int a) { return ants[a].alive; }
pos find_ant(int a) { return ants[a].p; }
void kill_ant_at(pos p) {
	trace(ant_at(p));
	trace("die");
	tracel();
	ants[ant_at(p)].alive=0;
	clear_ant_at(p);
}

int food_at(pos p) { return world[p.x][p.y].food; }
void set_food_at(pos p, int f) { world[p.x][p.y].food=f; }

int anthill_at(pos p, col c) {
	return c==red?world[p.x][p.y].redhill:world[p.x][p.y].blackhill;
}

int has_food(int a) { return ants[a].has_food; }

void set_marker_at(pos p, col c, int mark) {
	if(c==red) { world[p.x][p.y].redmark|=(1<<mark); }
	else       { world[p.x][p.y].blackmark|=(1<<mark); }
}

void clear_marker_at(pos p, col c, int mark) {
	if(c==red) { world[p.x][p.y].redmark&=~(1<<mark); }
	else       { world[p.x][p.y].blackmark&=~(1<<mark); }
}

int check_marker_at(pos p, col c, int mark) {
	if(c==red) { return world[p.x][p.y].redmark&(1<<mark); }
	else       { return world[p.x][p.y].blackmark&(1<<mark); }
}

int check_any_marker_at(pos p, col c) {
	if(c==red) { return world[p.x][p.y].redmark; }
	else       { return world[p.x][p.y].blackmark; }
}


int cell_matches(pos p, condition cond, col c) {
	if (rocky(p)) return cond==rock;
	
	switch(cond) {
		case fr:
			return some_ant_is_at(p) && ants[ant_at(p)].colour==c;
		case foe:
			return some_ant_is_at(p) && ants[ant_at(p)].colour!=c;
		case frfood:
			return some_ant_is_at(p) && ants[ant_at(p)].colour==c &&
			  has_food(ant_at(p));
		case foefood:
			return some_ant_is_at(p) && ants[ant_at(p)].colour!=c &&
			  has_food(ant_at(p));
		case food:
			return food_at(p);
		case rock:
			return 0;
		case mark0:return check_marker_at(p,c,0);		
		case mark1:return check_marker_at(p,c,1);		
		case mark2:return check_marker_at(p,c,2);		
		case mark3:return check_marker_at(p,c,3);		
		case mark4:return check_marker_at(p,c,4);		
		case mark5:return check_marker_at(p,c,5);		
		case foemark:return check_any_marker_at(p,other_col(c));
		case home: return anthill_at(p,c);
		case foehome:return anthill_at(p,other_col(c));
		default:warn("cell_matches: invalid condition"); return 0;
	}
}



inst get_instruction(col c, int state) {
	if (state>proglen[c==red?0:1]) { warn("invalid state"); fprintf(stderr,"col %d state %d\n",c,state); }
	return prog[c==red?0:1][state];
}

sense_dir parse_sd(char *b) { 
	if (!strcasecmp(b,"Here")) return here;
	if (!strcasecmp(b,"Ahead")) return ahead;
	if (!strcasecmp(b,"LeftAhead")) return lahead;
	if (!strcasecmp(b,"RightAhead")) return rahead;
	warn("invalid sd");
	return here;
}

condition parse_cond(char *b, char *m) {
	if (!strcasecmp(b,"Friend")) return fr;
	if (!strcasecmp(b,"Foe")) return foe;
	if (!strcasecmp(b,"FriendWithFood")) return frfood;
	if (!strcasecmp(b,"FoeWithFood")) return foefood;
	if (!strcasecmp(b,"Food")) return food;
	if (!strcasecmp(b,"Rock")) return rock;
	if (!strcasecmp(b,"Marker")) {
		if (m[0]>='0' && m[0]<='5' && m[1]==0) {
			switch(m[0]-'0') {
				case 0:return mark0;
				case 1:return mark1;
				case 2:return mark2;
				case 3:return mark3;
				case 4:return mark4;
				case 5:return mark5;
			}
		}
		warn("invalid marker #");
		return mark0;
	}
	if (!strcasecmp(b,"FoeMarker")) return foemark;
	if (!strcasecmp(b,"Home")) return home;
	if (!strcasecmp(b,"FoeHome")) return foehome;
	warn("invalid cond");
	return fr;
}

lor parse_lor(char *b) {
	if (!strcasecmp(b,"Left")) return left;
	if (!strcasecmp(b,"Right")) return right;
	warn("invalid lor");
	return left;
}

void readant(char *fname, int a) {

	//fprintf(stderr,"Opening %s as ant #%d.\n",fname,a);

	FILE *f=fopen(fname,"r");

	if (!f) { warn("file read error"); exit(1); }

	char line[500];
	char buf[8][20];
  int x=0;
 
	while(1) {
		if(!fgets(line,500,f)) break;
		for(int i=0;i<6;i++) buf[i][0]=0;
		sscanf(line,"%s%s%s%s%s%s",buf[0],buf[1],buf[2],buf[3],buf[4],buf[5]);
		
		if(!strcasecmp(buf[0],"Sense")) {
			prog[a][x].t=sense;
			prog[a][x].sd=parse_sd(buf[1]);
			prog[a][x].st0=atoi(buf[2]);
			prog[a][x].st1=atoi(buf[3]);
			prog[a][x].cond=parse_cond(buf[4],buf[5]);
		}
		else if(!strcasecmp(buf[0],"Mark")) {
			prog[a][x].t=mark;
			prog[a][x].marker=atoi(buf[1]);
			prog[a][x].st0=atoi(buf[2]);
		}
		else if(!strcasecmp(buf[0],"Unmark")) {
			prog[a][x].t=unmark;
			prog[a][x].marker=atoi(buf[1]);
			prog[a][x].st0=atoi(buf[2]);
		}
		else if(!strcasecmp(buf[0],"PickUp")) {
			prog[a][x].t=pickup;
			prog[a][x].st0=atoi(buf[1]);
			prog[a][x].st1=atoi(buf[2]);
		}
		else if(!strcasecmp(buf[0],"Drop")) {
			prog[a][x].t=drop;
			prog[a][x].st0=atoi(buf[1]);
		}
		else if(!strcasecmp(buf[0],"Turn")) {
			prog[a][x].t=iturn;
			prog[a][x].lr=parse_lor(buf[1]);
			prog[a][x].st0=atoi(buf[2]);
		}
		else if(!strcasecmp(buf[0],"Move")) {
			prog[a][x].t=move;
			prog[a][x].st0=atoi(buf[1]);
			prog[a][x].st1=atoi(buf[2]);
		}
		else if(!strcasecmp(buf[0],"Flip")) {
			prog[a][x].t=flip;
			prog[a][x].flipint=atoi(buf[1]);
			prog[a][x].st0=atoi(buf[2]);
			prog[a][x].st1=atoi(buf[3]);
		} else {
			warn("unrecognised command");
			warn(buf[0]);
		}
		x++;
	}
	proglen[a]=x;
	fclose(f);
}

void readworld(char *fname) {
	FILE *f=fopen(fname,"r");
	fscanf(f,"%d%d",&X,&Y);
	char buf[5];
	int i,j;
	for(j=0;j<Y;j++) for(i=0;i<X;i++) {
		if (fscanf(f,"%2s",buf)!=1) warn("out of data");
		switch(buf[0]) {
			case '#':world[i][j].rock=1; break;
			case '.':break;
			case '+':world[i][j].redhill=1; break;
			case '-':world[i][j].blackhill=1; break;
			default:
			  if (buf[0]>='1' && buf[0]<='9') world[i][j].food=buf[0]-'0';
			  else warn("invalid char in world file");
		}
	}
  if (fscanf(f,"%2s",buf)==1) warn("extraneous data");
	fclose(f);
}

int adjacent_ants(pos p, col c) {
	int ret=0;
	int d;
	for(d=0;d<6;d++) {
		pos cel=adjacent_cell(p,d);
		if (some_ant_is_at(cel) && ants[ant_at(cel)].colour==c) ret++;
	}
	return ret;
}

void check_for_surrounded_ant_at(pos p) {
	if (some_ant_is_at(p)) {
		int a=ant_at(p);
		if (adjacent_ants(p,other_col(ants[a].colour))>=5) {
			kill_ant_at(p);
			set_food_at(p,food_at(p)+3+(ants[a].has_food?1:0));
		}
	}
}

void check_for_surrounded_ants(pos p) {
	check_for_surrounded_ant_at(p);
	for(int d=0;d<6;d++)
	  check_for_surrounded_ant_at(adjacent_cell(p,d));
}


unsigned randomint(unsigned n) {
	static unsigned seed=12345;
	static int init=0;

  if (!n) { seed=12345; init=0; return 0; }
	
	if (!init) {
		for(int i=0;i<4;i++) {
			seed=seed*22695477+1;
		}
	}
	init++;
	
	unsigned x=(seed/65536)%16384;

  unsigned testx[4]={7193,2932,10386,5575};
	if(init<=4 && x!=testx[init-1]) {
		warn("number gen");
	}

	seed=seed*22695477+1;
	return x%n;
}


void step(int anum) {
	pos p1(0,0);
	if (ant_is_alive(anum)) {
		pos p=find_ant(anum);
		ant &a=ants[anum];
		if (a.resting) {
			a.resting--;
		} else {
			inst i=get_instruction(a.colour,a.state);
			switch(i.t) {
				case sense:
					p1=sensed_cell(p,a.d,i.sd);
					if (cell_matches(p1,i.cond,a.colour))
					  a.state=i.st0;
					else
						a.state=i.st1;

				break;
				case mark:
					set_marker_at(p,a.colour,i.marker);
					a.state=i.st0;

					trace(anum);
					trace("mark");
					trace(i.marker);
					tracel();

				break;
				case unmark:
					clear_marker_at(p,a.colour,i.marker);
					a.state=i.st0;

					trace(anum);
					trace("unmark");
					trace(i.marker);
					tracel();

				break;
				case pickup:
					if (a.has_food || food_at(p)==0)
						a.state=i.st1;
					else {
						set_food_at(p,food_at(p)-1);
						a.has_food=1;
						a.state=i.st0;

						trace(anum);
						trace("pickup");
						tracel();

					}
				break;
				case drop:
					if (a.has_food) {
						set_food_at(p,food_at(p)+1);
						a.has_food=0;
						trace(anum);
						trace("drop");
						tracel();
					}
					a.state=i.st0;
				break;
				case iturn:
					a.d=turn(i.lr,a.d);
					a.state=i.st0;
					
					trace(anum);
					trace("turn");
					i.lr==left?trace("l"):trace("r");
					tracel();
					
				break;
				case move:
					p1=adjacent_cell(p,a.d);
					if (rocky(p1) || some_ant_is_at(p1))
					  a.state=i.st1;
					else {
						trace(anum);
						trace("move");
						tracel();
						
						clear_ant_at(p);
						set_ant_at(p1,anum);
						a.state=i.st0;
						a.p=p1;
						a.resting=14;
						check_for_surrounded_ants(p1);
					}
				break;
				case flip:
					a.state=(randomint(i.flipint)==0)?i.st0:i.st1;
				break;
				default:
					warn("invalid instruction in step()");
					printf("col %c line %d\n",a.colour==red?'r':'b',a.state);
					printf("inst=%d dir=%d sd=%d lr=%d st0=%d st1=%d cond=%d fi=%d mark=%d\n",
					  i.t,i.d,i.sd,i.lr,i.st0,i.st1,i.cond,i.flipint,i.marker);
			}			
		}
	}
}



void play(char *world1, char *ant1, char *ant2) {
	readworld(world1);
	readant(ant1,0);
	readant(ant2,1);
	
	tfile=dotrace?fopen("trace.txt","w"):0;
	if (dotrace && !tfile) { warn("couldn't open trace file"); exit(1); }
	
	for(int y=0;y<Y;y++)
	for(int x=0;x<X;x++) {
		if (world[x][y].redhill || world[x][y].blackhill) {
			world[x][y].ant=A;
			ant &a=ants[A];
			a.id=A;			
			a.colour=world[x][y].redhill?red:black;
			a.state=0;
			a.resting=0;
			a.d=0;
			a.has_food=0;
			a.alive=1;
			a.p=pos(x,y);
			A++;
		}
		else world[x][y].ant=-1;
	}

#ifdef DUMP
	FILE *dump=fopen("mydump","w");
#endif
	
	for(int i=0;i<100000;i++) {
		stepnumber=i;

#ifdef DUMP
		fprintf(dump,"\nAfter round %d...\n",i);
		for(int y=0;y<Y;y++)
		for(int x=0;x<X;x++) {
			pos p(x,y);
			fprintf(dump,"cell (%d, %d): ",x,y);
			if (rocky(p)) fprintf(dump,"rock");
			if (world[x][y].food) fprintf(dump,"%d food; ",world[x][y].food);
			if (world[x][y].blackhill) fprintf(dump,"black hill; ");
			if (world[x][y].redhill) fprintf(dump,"red hill; ");
			if (world[x][y].redmark) {
				fprintf(dump,"red marks: ");
				for(int i=0;i<6;i++) if (world[x][y].redmark&(1<<i)) fprintf(dump,"%d",i);
				fprintf(dump,"; "); 
			}
			if (world[x][y].blackmark) {
				fprintf(dump,"black marks: ");
				for(int i=0;i<6;i++) if (world[x][y].blackmark&(1<<i)) fprintf(dump,"%d",i);
				fprintf(dump,"; "); 
			}
			if (world[x][y].ant>=0) {
				ant &a=ants[world[x][y].ant];
				fprintf(dump,"%s ant of id %d, dir %d, food %d, state %d, resting %d",
					a.colour==red?"red":"black",world[x][y].ant,a.d,a.has_food,a.state,a.resting);
			}
			fprintf(dump,"\n");
		}
#endif

		for(int a=0;a<A;a++) {
			step(a); 	
		}
		trace(-1);
		tracel();
	}

	int redscore=0;
	int blackscore=0;

	for(int y=0;y<Y;y++)
	for(int x=0;x<X;x++) {
		if (world[x][y].redhill) {
			redscore+=world[x][y].food;	
		}
		if (world[x][y].blackhill) {
			blackscore+=world[x][y].food;	
		}
	}

	int redalive=0,redtot=0;
	int blackalive=0,blacktot=0;

	for(int i=0;i<A;i++) {
		if (ants[i].colour==red) redtot++,redalive+=ants[i].alive;
		else blacktot++,blackalive+=ants[i].alive;
	}

  if (!flipped) {
  	global_score_red+=redscore;
  	global_score_black+=blackscore;
	  printf("map %s, score: red   %3d black %3d  (red   %2d black %2d)\n",world1,redscore,blackscore,redalive,blackalive);
	 } else {
  	global_score_red+=blackscore;
  	global_score_black+=redscore;
	  printf("map %s, score: black %3d red   %3d  (black %2d red   %2d)\n",world1,blackscore,redscore,blackalive,redalive);
	 }

#if 0
	  printf("(%2d/%2d alive.\t",redalive,redtot);
		printf("black has %2d/%2d ants alive.\n",blackalive,blacktot);
#endif
	
	if (tfile) { fclose(tfile); tfile=0; }
	return;	
}

void clearworld(void) {
	proglen[0]=proglen[1]=0;
	tfile=0;
	for(int i=0;i<100;i++) for(int j=0;j<100;j++) {
		world[i][j].ant=0;
		world[i][j].food=0;
		world[i][j].redmark=0;
		world[i][j].blackmark=0;
		world[i][j].rock=0;
		world[i][j].redhill=0;
		world[i][j].blackhill=0;
	}	
	X=Y=A=0;
	stepnumber=0;
	randomint(0);
}


int main(int argc, char *argv[]) {
	if (argc!=4 && argc!=5) {
		puts("usage: sim worldfile antfile1 antfile2 <bool_dotrace>");
	}
	dotrace=argc==4 || argv[4][0]!='0' || argv[4][1]!=0;

	if (argv[2][strlen(argv[2])-1]=='c') {
		char buf[200];
		printf("compiling %s.\n",argv[2]);
		sprintf(buf,"perl compiler/antc.pl %s",argv[2]);
		system(buf);
		argv[2][strlen(argv[2])-1]=0;
	}
	if (argv[3][strlen(argv[3])-1]=='c') {
		char buf[200];
		printf("compiling %s.\n",argv[3]);
		sprintf(buf,"perl compiler/antc.pl %s",argv[3]);
		system(buf);
		argv[3][strlen(argv[3])-1]=0;
	}


	printf("%s vs %s\n",argv[2],argv[3]);
	
	
  if (!strcasecmp("all",argv[1])) {
  	int i;
  	for(i=0;i<10;i++) {
  		char buf[50];
  		sprintf(buf,"worlds/sample%d.world",i);
  		play(buf,argv[2],argv[3]);
  		dotrace=0;
  		if (strcmp(argv[2],argv[3])) {
  			flipped=1;
  			clearworld();
  			play(buf,argv[3],argv[2]);
  			flipped=0;
  		}
  		clearworld();
   	}
   	printf("Total score:");
   	printf("%25s %04d-%04d %-25s\n",argv[2],global_score_red,global_score_black,argv[3]);
  }	else {
  	play(argv[1],argv[2],argv[3]);
  }
	
  return 0;
}
