/**
 *   Util funcs
 */
#include <string.h>
#include <stdlib.h>
#include <time.h>
void die(char *s) ;
void warn(char *s) ;
void *mymalloc(int n) ;
void *myrealloc(void *p, int n) ;
void *mystrdup(char *) ;
int mrand(int i) ;
int exterseconds() ;
int iabs(int) ;
