void calcdist(char **board, int **dists, int w, int h, int x, int y) ;
