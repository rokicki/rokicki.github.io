package codes ;
require Exporter ;
@ISA = qw(Exporter) ;
@EXPORT = qw(congruent plcost costtriple inf relevant morerefined refine
             transcost adjstates) ;
use strict ;
use vars qw($inf) ;
$inf = 10_000_000 ;
#
#   Find the relevant bits from a character.
#
sub relevant {
   my $st = shift ;
   return 0xffff if ($st & 0x80) ;
   return 0xf70 if ($st & 0xf080) == 0xe000 ;
   return 0xff70 ;
}
sub congruent {
   my ($st1, $st2) = @_ ;
   my $rel = relevant($st1) & relevant($st2) ;
   return !(($st1 ^ $st2) & $rel) ;
}
#
#   Only call when both are congruent!
#
sub morerefined {
   my ($st1, $st2) = @_ ;
   return $st1 if (relevant($st1) > relevant($st2)) ;
   return $st2 ;
}
sub refine {
   my ($st1, $st2) = @_ ;
   my $rel = relevant($st1) ;
   return (($st1 & $rel) | ($st2 & ~$rel)) & 0xffff ;
}
sub simpcost {
   my $st1 = shift ;
   return (($st1 & 0x10) ? 9 : 0) + (($st1 & 8) ? 7 : 0) +
          (($st1 & 4) ? 7 : 0) + ((($st1 & 0xa) == 2) ? 9 : 0) +
          (($st1 & 1) ? 7 : 0) + ((($st1 & 0x60) >> 5) * 7) ;
}
sub plcost {
   my $st1 = shift ;
   return 9 + simpcost($st1) ;
}
sub costtriple {
   my ($st1, $st2) = @_ ;
   my $rel = relevant($st1) & relevant($st2) ;
   my $reldiff = ($st1 ^ $st2) & $rel ;
   my @colorcost = (0, 0, 0) ;
   if ($reldiff & 0xf000) {
      if (($st1 & 0xf000) == 0xf000) {
         @colorcost = (7, $inf, 7) ;
      } elsif (($st2 & 0xf000) == 0xf000) {
         @colorcost = ($inf, 7, 7) ;
      } else {
         @colorcost = (7, 7, 7) ;
      }
   }
   my @sizecost = (0, 0, 0) ;
   if ($reldiff & 0xf00) {
      if (($st1 & 0xf00) == 0xf00) {
         @sizecost = (7, $inf, 7) ;
      } elsif (($st2 & 0xf00) == 0xf00) {
         @sizecost = ($inf, 7, 7) ;
      } else {
         @sizecost = (7, 7, 7) ;
      }
   }
   my @othercost = (0, 0, 0) ;
   $othercost[2] += 7 if ($reldiff & 0x1) ;
   $othercost[2] += 9 if (($reldiff & 0xa) == 0x2) && (($st1 & 0x8) == 0) ;
   $othercost[2] += 7 if ($reldiff & 0x4) ;
   $othercost[2] += 7 if ($reldiff & 0x8) ;
   $othercost[2] += 9 if ($reldiff & 0x10) ;
   my $uudiff = (($st1 & 0x60) - ($st2 & 0x60)) / 32 ;
   if ($uudiff < 0) {
      $othercost[2] -= 7 * $uudiff ;
   } else {
      $othercost[2] += 7 * $uudiff ;
   }
   my $pl1 = plcost($st1) ;
   my $pl2 = plcost($st2) ;
   if ((($st1 & ~$st2) & 0x1d) || $uudiff > 0 || $pl2 < $othercost[2]) {
      $othercost[0] = $pl2 ;
   } else {
      $othercost[0] = $othercost[2] ;
   }
   if ((($st2 & ~$st1) & 0x1d) || $uudiff < 0 || $pl1 < $othercost[2]) {
      $othercost[1] = $pl1 ;
   } else {
      $othercost[1] = $othercost[2] ;
   }
   for (0..2) { $othercost[$_] += $sizecost[$_] + $colorcost[$_] }
   $othercost[2] = $othercost[0] if ($othercost[0] < $othercost[2]) ;
   $othercost[2] = $othercost[1] if ($othercost[1] < $othercost[2]) ;
   @othercost = map { my $r = $othercost[$_] ; ($r <= $inf ? $r : $inf) } 0..2 ;
#  printf STDERR ("CT %x %x %d %d %d\n", $st1, $st2, @othercost) ;
   return @othercost ;
}
sub transcost {
   my ($st1, $st2) = @_ ;
   my $rel = relevant($st1) & relevant($st2) ;
   my $reldiff = ($st1 ^ $st2) & $rel ;
   my $cost = 0 ;
   if ($reldiff & 0xf000) {
      if (($st2 & 0xf000) == 0xf000) {
         return $inf ;
      }
      $cost = 7 ;
   }
   if ($reldiff & 0xf00) {
      if (($st2 & 0xf00) == 0xf00) {
         return $inf ;
      }
      $cost += 7 ;
   }
   my $othercost = 0 ;
   my $uudiff = (($st2 & 0x60) - ($st1 & 0x60)) / 32 ;
   if ((($st1 & ~$st2) & 0x1d) || $uudiff < 0) {
      return $cost + plcost($st2) ;
   }
   return $cost + simpcost($reldiff & 0x7f) ;
}
#
#   Return the adjacency states and costs.  Might be up to 16 states!
#   2x for color, 2x for size, and 4x for the stupid em bit and different
#   ways of using pl.  And there might be a bunch of different costs.
#
sub adjstates {
   my ($st1, $st2) = @_ ;
   my $rel = relevant($st1) & relevant($st2) ;
   my $reldiff = ($st1 ^ $st2) & $rel ;
   my @colorpossib = ($st1 & 0xf000) ;
   my $colorcost = 0 ;
   if ($reldiff & 0xf000) {
      $colorcost = 7 ;
      if (($st1 & 0xf000) == 0xf000 || ($st2 & 0xf000) == 0xf000) {
         @colorpossib = (0xf000) ;
      } else {
         @colorpossib = (($st1 & 0xf000), ($st2 & 0xf000)) ;
      }
   }
   my @sizepossib = ($st1 & 0xf00) ;
   my $sizecost = 0 ;
   if ($reldiff & 0xf00) {
      $sizecost = 7 ;
      if (($st1 & 0xf00) == 0xf00 || ($st2 & 0xf00) == 0xf00) {
         @sizepossib = (0xf00) ;
      } else {
         @sizepossib = (($st1 & 0xf00), ($st2 & 0xf00)) ;
      }
   }
   my $charbit = ($st1 | $st2) & 0x80 ;
   my @plpossib = () ;
   my $pl1 = plcost($st1) ;
   my $pl2 = plcost($st2) ;
   if ((($st1 ^ $st2) & 0x7f) == 0) {
      push @plpossib, [($st1 & 0x7f) | $charbit, 0] ;
   } else {
      my $uudiff = (($st1 & 0x60) - ($st2 & 0x60)) / 32 ;
      my $uustate = 0 ;
      my $othercost = 0 ;
      if ($uudiff < 0) {
         $othercost = -7 * $uudiff ;
         $uustate = $st1 & 0x60 ;
      } else {
         $othercost = 7 * $uudiff ;
         $uustate = $st2 & 0x60 ;
      }
      $uustate |= $charbit ;
#  four possibilities:  st1 using pl2, st2 using pl1,
#  st1 & st2 using simpcost,
#  ((st1 & st2) ^ em) using simpcost iff ((st1 ^ st2) & em)
#  these might overlap.  Each with own cost.
      my $sc = simpcost($reldiff & 0x1f) + $othercost ;
      push @plpossib, [refine($st1, $st2) & 0xff, $pl2] ;
      push @plpossib, [refine($st2, $st1) & 0xff, $pl1] ;
      if (($reldiff & 0xa) == 0xa) { # then neither is space
         push @plpossib, [($st1 & $st2 & 0x1f) | 2 | $uustate, $sc] ;
      } elsif (($st1 & 0x80) == 0 || ($st2 & 0x80) == 0) { # one is space, maybe both
         push @plpossib, [(($st1 | $st2) & 0x1f) | $uustate, $sc] ;
      } else {
         push @plpossib, [($rel & $st1 & $st2 & 0x1f) | $uustate, $sc] ;
         push @plpossib, [(($st1 & $st2 & 0x1f) ^ 2) | $uustate, $sc]
                                                     if ($reldiff & 0xa) == 2 ;
      }
      my $i ;
      my $j ;
      for ($i=1; $i<@plpossib; $i++) {
         for ($j=0; $j<$i; $j++) {
            if ($plpossib[$i]->[0] == $plpossib[$j]->[0]) {
               if ($plpossib[$i]->[1] < $plpossib[$j]->[1]) {
                  $plpossib[$j]->[1] = $plpossib[$i]->[1] ;
               }
               splice(@plpossib, $i, 1) ;
               $i-- ;
               last ;
            }
         }
      }
   }
   my @r = () ;
   my $i ;
   for $i (@colorpossib) {
      my $j ;
      for $j (@sizepossib) {
         my $bits = $i | $j ;
         for (@plpossib) {
            push @r, [$_->[0] | $bits, $_->[1] + $colorcost + $sizecost] ;
         }
      }
   }
   return @r ;
}
1;
