#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define INF 10000000
typedef struct node {
   struct node *next, *prev, *main, *child ;
   int state, forward, back, best ;
   int loc, endloc ;
   char childprecedes ;
} node ;
int bufferlen, filelen, brackets ;
char *orig, *trial ;
node *nodes, *firstnode ;
int nodealloc ;
node **topnodes ;
int topnodemax = 0 ;
node *newnode(node *pred, int state, int loc) {
   node *r = nodes ;
   nodes = nodes->next ;
   r->next = 0 ;
   nodealloc++ ;
   r->prev = pred ;
   r->state = state ;
   r->loc = loc ;
   if (pred) {
      pred->endloc = loc ;
      pred->next = r ;
   }
   topnodes[topnodemax++] = r ;
   return r ;
}
int relevant(int s) {
   if (s & 0x80)
      return 0xffff ;
   if ((s & 0xf080) == 0xe000)
      return 0xf70 ;
   return 0xff70 ;
}
int refine(int s1, int s2) {
   int rel = relevant(s1) ;
   return (s1 & rel) | (s2 & ~rel) ;
}
void setcosts(node *n, int newstate) ;
node *newcomb(node *main, node *child, int childprecedes,
              node *prev, node *next) {
   node *r = nodes ;
   nodes = nodes->next ;
   nodealloc++ ;
   r->prev = prev ;
   r->next = next ;
   r->main = main ;
   r->child = child ;
   r->childprecedes = childprecedes ;
   if (prev)
      prev->next = r ;
   if (next)
      next->prev = r ;
   if (child->endloc > main->endloc)
      r->endloc = child->endloc ;
   else
      r->endloc = main->endloc ;
   if (prev == 0)
      firstnode = r ;
   r->state = refine(main->state, child->state) ;
   if (r->next)
      setcosts(r, r->next->state) ;
   if (r->prev)
      setcosts(r->prev, r->state) ;
   child->next = main->next = 0 ;
   topnodes[topnodemax++] = r ;
   return r ;
}
int plcostarr[128] ;
int plcost(int s) {
   return plcostarr[s & 0x7f] ;
}
void startplcost() {
   int i ;
   for (i=0; i<128; i++) {
      int r = 9 ;
      if (i & 1)
         r += 7 ;
      if (i & 2)
         r += 9 ;
      if (i & 4)
         r += 7 ;
      if (i & 8)
         r += 7 ;
      if (i & 0x10)
         r += 9 ;
      r += ((i & 0x60) >> 5) * 7 ;
      plcostarr[i] = r ;
   }
}
void costtriple(int *costs, int st1, int st2) {
   int rel = relevant(st1) & relevant(st2) ;
   int pl1, pl2, reldiff = (st1 ^ st2) & rel ;
   int uudiff, res[3], other[3] ;
   other[0] = other[1] = other[2] = res[0] = res[1] = res[2] = 0 ;
   if (reldiff & 0xf000) {
      if ((st1 & 0xf000) == 0xf000) {
         res[0] = res[2] = 7 ;
         res[1] = INF ;
      } else if ((st2 & 0xf000) == 0xf000) {
         res[1] = res[2] = 7 ;
         res[0] = INF ;
      } else {
         res[0] = res[1] = res[2] = 7 ;
      }
   }
   if (reldiff & 0xf00) {
      if ((st1 & 0xf00) == 0xf00) {
         res[0] += 7 ;
         res[2] += 7 ;
         res[1] = INF ;
      } else if ((st2 & 0xf00) == 0xf00) {
         res[1] += 7 ;
         res[2] += 7 ;
         res[0] = INF ;
      } else {
         res[0] += 7 ;
         res[1] += 7 ;
         res[2] += 7 ;
      }
   }
   if (reldiff & 1)
      other[2] += 7 ;
   if ((reldiff & 0xa) == 0x2 && (st1 & 8) == 0)
      other[2] += 9 ;
   if (reldiff & 4)
      other[2] += 7 ;
   if (reldiff & 8)
      other[2] += 7 ;
   if (reldiff & 0x10)
      other[2] += 9 ;
   uudiff = ((st1 & 0x60) - (st2 & 0x60)) >> 5 ;
   if (uudiff < 0) {
      other[2] -= 7 * uudiff ;
   } else {
      other[2] += 7 * uudiff ;
   }
   pl1 = plcost(st1) ;
   pl2 = plcost(st2) ;
   if (((st1 & ~st2) & 0x1f) || uudiff > 0 || pl2 < other[2]) {
      other[0] = pl2 ;
   } else {
      other[0] = other[2] ;
   }
   if (((st2 & ~st1) & 0x1f) || uudiff < 0 || pl1 < other[2]) {
      other[1] = pl1 ;
   } else {
      other[1] = other[2] ;
   }
   costs[0] = other[0] + res[0] ;
   costs[1] = other[1] + res[1] ;
   costs[2] = other[2] + res[2] ;
   if (costs[2] > costs[0])
      costs[2] = costs[0] ;
   if (costs[2] > costs[1])
      costs[2] = costs[1] ;
}
void setcosts(node *n, int newstate) {
   int costs[3] ;
   costtriple(costs, n->state, newstate) ;
   n->forward = costs[0] ;
   n->back = costs[1] ;
   n->best = costs[2] ;
}
int cleanwhitestate(int state) {
   state &= 0xfff0 ;
   if ((state & 0x60) == 0) {
      state &= 0xff0 ;
      state |= 0xe000 ;
   }
   return state ;
}
int congruent(int st1, int st2) {
   int rel = relevant(st1) & relevant(st2) ;
   return 0 == (rel & (st1 ^ st2)) ;
}
int doop(int c, int s) {
   switch (c) {
case 'B': return s | 1 ;
case 'E': return (s & 8) ? s : s ^ 2 ;
case 'I': return s | 4 ;
case 'P': return s & 0xff80 ;
case 'S': return (s|8) & ~2 ;
case 'T': return s | 0x10 ;
case 'U': return (s & 0xff9f) | (((s & 0x60) + 0x20) & 0x60) ;
case '0': case '1': case '2': case '3': case '4': case '5': case '6':
case '7': case '8': case '9': return (s & 0xf0ff) | ((c - '0') << 8) ;
case 'r': return (s & 0xfff) | 0x0000 ;
case 'g': return (s & 0xfff) | 0x1000 ;
case 'b': return (s & 0xfff) | 0x2000 ;
case 'c': return (s & 0xfff) | 0x3000 ;
case 'm': return (s & 0xfff) | 0x4000 ;
case 'y': return (s & 0xfff) | 0x5000 ;
case 'k': return (s & 0xfff) | 0x6000 ;
case 'w': return (s & 0xfff) | 0x7000 ;
default:
      abort() ;
   }
}
node *rotateleft(node *this) {
   node *left = this->prev ;
   return newcomb(left, this, 0, left->prev, this->next) ;
}
node *rotateright(node *this) {
   node *right = this->next ;
   return newcomb(right, this, 1, this->prev, right->next) ;
}
unsigned short *statestack ;
int statesp ;
void peep(node *this, int maxloc) {
   if (this->prev)
      this = this->prev ;
   for (; this && this->next && this->endloc < maxloc; this = this->next) {
      int c1, c2, gocost ;
again:
      if (!this->prev)
         continue ;
      c1 = this->prev->state ;
      c2 = this->next->state ;
      gocost = this->prev->forward ;
      if ((c1 == c2 || congruent(c1, c2)) && gocost == this->prev->best &&
          this->back == this->best) {
         this = rotateright(this) ;
         this = rotateleft(this) ;
         if (this->prev)
            this = this->prev ;
         goto again ;
      }
      if (gocost == this->prev->best) {
         int cmid = this->state ;
         int newcode = refine(c1, cmid) ;
         int costs[3] ;
         costtriple(costs, newcode, c2) ;
         if (gocost + costs[0] <= this->forward &&
             gocost + costs[1] <= this->back &&
             gocost + costs[2] <= this->best) {
            this = rotateleft(this) ;
            if (this->prev)
               this = this->prev ;
            goto again ;
         }
      }
      gocost = this->back ;
      if (gocost == this->best) {
         int cmid = this->state ;
         int newcode = refine(c2, cmid) ;
         int costs[3] ;
         costtriple(costs, c1, newcode) ;
         if (gocost + costs[0] <= this->prev->forward &&
             gocost + costs[1] <= this->prev->back &&
             gocost + costs[2] <= this->prev->best) {
            this = rotateright(this) ;
            if (this->prev)
               this = this->prev ;
            goto again ;
         }
      }
   }
}
int laststate = -1 ;
int outlen ;
void tryspace(int c, int state) {
   state &= 0xff70 ;
   if ((state & 0x60) == 0)
      state &= 0xf70 ;
   if (laststate != state) {
      trial[outlen++] = c ;
      laststate = state ;
   }
}
char *tags[20] ;
char *colortag[] = { "r", "g", "b", "c", "m", "y", "k", "w" } ;
char *sizetag[] = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" } ;
int transition(int st1, int st2) {
   int r = 0 ;
   int diff = st1 ^ st2 ;
   int newstate = st1 ;
   int uudiff ;
   if ((st2 & 0x80) == 0) {
      diff &= 0xff70 ;
      if ((st2 & 0x60) == 0)
         diff &= 0xf70 ;
   }
   if ((diff & 0xf000) != 0 && ((st2 & 0xf000) != 0xe000)) {
      tags[r] = colortag[st2 >> 12] ;
      newstate = doop(tags[r++][0], newstate) ;
   }
   if ((diff & 0xf00) != 0) {
      tags[r] = sizetag[(st2 >> 8) & 0xf] ;
      newstate = doop(tags[r++][0], newstate) ;
   }
   uudiff = ((st2 & 0x60) - (st1 & 0x60)) / 32 ;
   if (uudiff < 0 || (diff & st1 & ~st2 & 0x1f)) {
      tags[r] = "PL" ;
      newstate = doop(tags[r++][0], newstate) ;
   } else {
      while (uudiff-- > 0) {
         tags[r] = "U" ;
         newstate = doop(tags[r++][0], newstate) ;
      }
      if (diff & 0x10) {
         tags[r] = "TT" ;
         newstate = doop(tags[r++][0], newstate) ;
      }
      if (diff & 8) {
         tags[r] = "S" ;
         newstate = doop(tags[r++][0], newstate) ;
      }
      if (diff & 4) {
         tags[r] = "I" ;
         newstate = doop(tags[r++][0], newstate) ;
      }
      if (diff & 2) {
         tags[r] = "EM" ;
         newstate = doop(tags[r++][0], newstate) ;
      }
      if (diff & 1) {
         tags[r] = "B" ;
         newstate = doop(tags[r++][0], newstate) ;
      }
   }
   tags[r] = 0 ;
   return newstate ;
}
void msend(node *node, int state) {
   int newstate = transition(state, node->state) ;
   int i, ntags = 0 ;
   for (i=0; tags[i]; i++) {
      trial[outlen++] = '<' ;
      strcpy(trial+outlen, tags[i]) ;
      outlen += strlen(trial + outlen) ;
      trial[outlen++] = '>' ;
      ntags++ ;
   }
   if (!node->child) {
      i = node->loc ;
      if (outlen + node->endloc - node->loc > 5000 + filelen) {
         return ;
      }
      for (; i<node->endloc; i++) {
         int c ;
         c = orig[i] ;
         if (c == '<') {
            while (orig[i] != '>')
               i++ ;
         } else if (c > ' ' || (newstate & 0x10)) {
            trial[outlen++] = c ;
            laststate = -1 ;
         } else {
            tryspace(c, newstate) ;
         }
      }
   } else {
      if (node->childprecedes)
         msend(node->child, newstate) ;
      msend(node->main, newstate) ;
      if (!node->childprecedes)
         msend(node->child, newstate) ;
   }
   transition(state, node->state) ;
   for (i=ntags-1; i>=0; i--) {
      trial[outlen++] = '<' ;
      trial[outlen++] = '/' ;
      strcpy(trial+outlen, tags[i]) ;
      outlen += strlen(trial + outlen) ;
      trial[outlen++] = '>' ;
   }
}
int main(int argc, char *argv[]) {
   int laststate, len, i, msize = 5000, sofar = 1 ;
   int state ;
   char *file = malloc(msize + 1) ;
   node *thisnode = 0 ;
   srand48(time(0)) ;
   startplcost() ;
   file[0] = 'x' ;
   while (1) {
      int togo = msize - sofar ;
      int len = fread(file + sofar, 1, togo, stdin) ;
      if (len > 0)
         sofar += len ;
      if (len == togo) {
         file = realloc(file, 2 * msize + 2) ;
         msize += msize ;
      } else {
         break ;
      }
   }
   file[sofar++] = 'x' ;
   orig = file ;
   filelen = sofar - 2 ;
   bufferlen = sofar ;
   orig[filelen] = 0 ;
   brackets = 0 ;
   trial = malloc(filelen + 5000) ;
   while ((file = index(file, '<')) != 0) {
      brackets++ ;
      file++ ;
   }
   statestack = calloc(brackets/2+10, sizeof(short)) ;
   statesp = 0 ;
   len = brackets * 2 + 100 ;
   nodes = calloc(len, sizeof(node)) ;
   topnodes = calloc(len, sizeof(node *)) ;
   for (i=0; i+1<len; i++)
      nodes[i].next = &(nodes[i+1]) ;
   state = 0xff00 ;
   thisnode = firstnode = newnode(0, state, 0) ;
   for (i=0; i<bufferlen; i++) {
      int c = orig[i] ;
      if (c == '<') {
         c = orig[++i] ;
         if (c == '/') {
            state = statestack[--statesp] ;
         } else {
            statestack[statesp++] = state ;
            state = doop(c, state) ;
         }
         while (orig[i] != '>')
            i++ ;
      } else if (c <= ' ') {
         int wstate = cleanwhitestate(state) ;
         if (!congruent(thisnode->state, wstate))
            thisnode = newnode(thisnode, wstate, i) ;
      } else {
         int cstate = state | 0x80 ;
         if (thisnode->state != cstate) {
            if (!congruent(thisnode->state, cstate)) {
               thisnode = newnode(thisnode, cstate, i) ;
            } else {
               thisnode->state = cstate ;
            }
         }
      }
   }
   thisnode->endloc = i ;
   laststate = -1 ;
   for (thisnode=firstnode; thisnode->next; thisnode=thisnode->next)
      setcosts(thisnode, thisnode->next->state) ;
   if (topnodemax > 2) {
      topnodemax-- ;
      topnodes[0] = topnodes[--topnodemax] ;
   }
   peep(firstnode, len) ;
   while (firstnode->next) {
      int pos, bestpos, bestdir = 1, best = INF ;
      node *bestnode = 0, *thisnode = 0 ;
      int c1, c2, gocost, cmid, endloc ;
      if (!firstnode->next->next) {
         rotateleft(firstnode->next) ;
         break ;
      }
      for (i=0; i<20; i++) {
         int dir, cost ;
         do {
            pos = lrand48() % topnodemax ;
            thisnode = topnodes[pos] ;
            if (thisnode->prev == 0 || thisnode->next == 0) {
               topnodemax-- ;
               topnodes[pos] = topnodes[topnodemax] ;
               pos = -1 ;
            }
         } while (pos < 0) ;
         dir = (lrand48() & 0x2) - 1 ;
         if (dir > 0)
            cost = thisnode->prev->forward ;
         else
            cost = thisnode->back ;
         if (cost < best) {
            best = cost ;
            bestpos = pos ;
            bestdir = dir ;
            bestnode = thisnode ;
            if (best == 7)
               break ;
         }
      }
      thisnode = bestnode ;
      c1 = thisnode->prev->state ;
      c2 = thisnode->next->state ;
      gocost = best ;
      cmid = thisnode->state ;
      if (bestdir > 0) {
         thisnode = rotateleft(thisnode) ;
         if (congruent(thisnode->state, thisnode->next->state)) {
            rotateright(thisnode) ;
         }
      } else {
         thisnode = rotateright(thisnode) ;
         if (congruent(thisnode->state, thisnode->prev->state)) {
            rotateleft(thisnode) ;
         }
      }
      endloc = thisnode->endloc ;
      if (thisnode->next)
         endloc = thisnode->next->endloc ;
      if (thisnode->prev)
         thisnode = thisnode->prev ;
      peep(thisnode, endloc) ;
   }
   msend(firstnode, 0xff00) ;
   if (outlen < filelen + 2) {
      fwrite(trial+1, 1, outlen - 2, stdout) ;
   } else {
      fwrite(orig+1, 1, bufferlen - 2, stdout) ;
   }
   exit(0) ;
}
