Name: Yuri Pertsovski
Email: yuri_p@walla.co.il
City,Country: Hazorea, Israel

The solver is based on Mark Jeays' solution #1

compilation: Nothing special, except the complier should yield one warning and on certain system (like Linux) there might be an error on return (but the program should still work) because I used void main.

run: like described on this site