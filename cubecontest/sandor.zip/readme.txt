name: Adrian Sandor
email: aditsu@yahoo.com
city: Hong Kong (they say it's in China)
compilation: probably g++ main.cpp -O3 -march=pentium4 -mcpu=pentium4
 if you know how to optimize it better then please do

the program uses the standard input and output
it was written in windows/mingw (with Dev-C++), I hope it runs in linux too
I will add more comments in the source later (and hopefully I'll also make it shorter,
faster and more efficient)
