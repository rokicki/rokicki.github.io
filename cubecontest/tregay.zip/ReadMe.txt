Grant Tregay
Grant@Tregay.net
West Chicago, IL USA

Compilation Instructions:  Nothing special that I know of.

Run Instructions: Ditto.

Additional Comments: I implemented a corner orientation improvement and fixed
   a bug in the CELL phase. Unfortunately, with the length of the code, adding
   to the codes efficiency isn't nearly as beneficial as making the solutions
   more efficient - which in turn adds a bit to the length of the code - grr...
   Time for a new approach, I think ;-)  Hopefully you don't mind getting so
   many submissions!

12345678901234567890123456789012345678901234567890123456789012345678901234567890
Additional Comments: Well, I thought I had submitted a third attempt, but didn't
   hear back.  Oh, well... I've made some corrections/improvements since then.
   This version will be a little longer than the previous ones, but should cut
   the move counts in better than half.  This should bump me up a spot or two on
   the leaderboard.  Unfortunately, with the length of the code, adding
   to the codes efficiency isn't nearly as beneficial as making the solutions
   more efficient - which in turn adds a bit to the length of the code - grr...
   Time for a new approach, I think ;-)  Hopefully you don't mind getting so
   many submissions!
